package com.allapps.floatingwindow.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Rect
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.WindowManagerHelper
import com.allapps.floatingwindow.data.SettingsRepository
import kotlin.math.abs

/** Root view of a floating window. Reports outside touches, touches and the Back key. */
class WindowFrame(context: Context) : FrameLayout(context) {
    var onOutsideTouch: (() -> Unit)? = null
    var onTouchUp: (() -> Unit)? = null
    var onBackPressed: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutsideTouch?.invoke()
            return true
        }
        val handled = super.dispatchTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP) post { onTouchUp?.invoke() }
        return handled
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
            onBackPressed?.invoke()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

/**
 * A real floating window drawn by this app with WindowManager. It has a title bar, minimize,
 * maximize and close buttons, a resize handle, rounded corners, adjustable opacity and snapping.
 * It hosts this app's own tools (launcher, calculator, notes); Android does not allow apps to
 * place other apps inside their windows.
 */
class FloatingWindow(
    service: Context,
    val kind: Kind,
    private val settings: SettingsRepository,
    private val theme: OverlayTheme,
    private val listener: Listener
) {

    enum class Kind(val titleRes: Int, val iconRes: Int) {
        LAUNCHER(R.string.window_launcher, R.drawable.ic_apps),
        CALCULATOR(R.string.window_calculator, R.drawable.ic_calculator),
        NOTES(R.string.window_notes, R.drawable.ic_notes)
    }

    interface Listener {
        fun onWindowClosed(window: FloatingWindow)
        fun onWindowMinimized(window: FloatingWindow)
        fun onWindowTouched(window: FloatingWindow)
    }

    val context: Context = theme.themedContext(service)
    private val wm = WindowManagerHelper.windowManager(context)
    val params = WindowManagerHelper.overlayParams(0, 0)
    val root = WindowFrame(context)
    private val contentHolder = FrameLayout(context)
    private val maximizeButton: ImageButton

    var isShowing = false
        private set
    var isMaximized = false
        private set
    private val restoreRect = Rect()
    private var closing = false

    init {
        val headerHeight = dp(44f)
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(theme.headerBg)
            setPadding(dp(12f), 0, dp(4f), 0)
        }
        val icon = ImageView(context).apply {
            setImageResource(kind.iconRes)
            setColorFilter(theme.accent)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(20f), dp(20f)))
        val title = TextView(context).apply {
            text = context.getString(kind.titleRes)
            setTextColor(theme.text)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(10f)
        })
        header.addView(headerButton(R.drawable.ic_minimize, R.string.cd_minimize) { minimize() })
        maximizeButton = headerButton(R.drawable.ic_maximize, R.string.cd_maximize) { toggleMaximize() }
        header.addView(maximizeButton)
        header.addView(headerButton(R.drawable.ic_close, R.string.cd_close) { close() })
        attachDrag(header)

        column.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, headerHeight))
        column.addView(contentHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val resize = ImageView(context).apply {
            setImageResource(R.drawable.ic_resize)
            setColorFilter(theme.textSecondary)
            contentDescription = context.getString(R.string.cd_resize)
            setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        }
        attachResize(resize)
        root.addView(resize, FrameLayout.LayoutParams(dp(30f), dp(30f), Gravity.BOTTOM or Gravity.END))

        root.onOutsideTouch = { setKeyboardEnabled(false) }
        root.onBackPressed = { setKeyboardEnabled(false) }
        root.onTouchUp = { listener.onWindowTouched(this) }
        applyAppearance()
    }

    fun setContent(view: View) {
        contentHolder.removeAllViews()
        contentHolder.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun show(rect: Rect) {
        if (isShowing) return
        applyRect(rect)
        WindowManagerHelper.clamp(context, params)
        addToScreen()
    }

    /** Hides the window while it is minimized. */
    fun hide() {
        if (!isShowing) return
        setKeyboardEnabled(false)
        removeFromScreen()
    }

    fun restore() {
        if (isShowing) return
        WindowManagerHelper.clamp(context, params)
        addToScreen()
    }

    fun minimize() {
        listener.onWindowMinimized(this)
    }

    fun close() {
        if (closing) return
        closing = true
        root.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f)
            .setDuration(animDuration(150))
            .withEndAction {
                removeFromScreen()
                listener.onWindowClosed(this)
            }
            .start()
    }

    /** Removes the window immediately, without animation (used when the service stops). */
    fun destroy() {
        root.animate().cancel()
        removeFromScreen()
    }

    /** Re-adds the window so it is drawn above the other floating windows. */
    fun bringToFront() {
        if (!isShowing) return
        try {
            wm.removeViewImmediate(root)
            wm.addView(root, params)
        } catch (e: Exception) {
            Log.w(TAG, "Could not bring window to front", e)
        }
    }

    fun setKeyboardEnabled(enabled: Boolean) {
        WindowManagerHelper.setFocusable(context, root, params, enabled)
    }

    fun toggleMaximize() {
        if (isMaximized) {
            applyRect(restoreRect)
            setMaximized(false)
        } else {
            saveRestoreRect()
            applyRect(WindowManagerHelper.rectFor(context, WindowManagerHelper.Snap.MAXIMIZE))
            setMaximized(true)
        }
        WindowManagerHelper.safeUpdate(context, root, params)
    }

    /** Applies the current opacity and corner radius settings. */
    fun applyAppearance() {
        val radius = dp(settings.cornerRadiusDp.toFloat()).toFloat()
        root.background = theme.rounded(theme.windowBg, radius, dp(1f))
        root.clipToOutline = true
        params.alpha = settings.windowOpacity / 100f
        WindowManagerHelper.safeUpdate(context, root, params)
    }

    fun keepOnScreen() {
        WindowManagerHelper.clamp(context, params)
        WindowManagerHelper.safeUpdate(context, root, params)
    }

    // ------------------------------------------------------------------ internals

    private fun addToScreen() {
        try {
            root.alpha = 0f
            root.scaleX = 0.92f
            root.scaleY = 0.92f
            wm.addView(root, params)
            isShowing = true
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(animDuration(180)).start()
        } catch (e: Exception) {
            Log.w(TAG, "Could not show floating window", e)
            isShowing = false
        }
    }

    private fun removeFromScreen() {
        if (!isShowing) return
        isShowing = false
        try {
            wm.removeViewImmediate(root)
        } catch (e: Exception) {
            Log.w(TAG, "Window already removed", e)
        }
    }

    private fun applyRect(r: Rect) {
        params.x = r.left
        params.y = r.top
        params.width = r.width()
        params.height = r.height()
    }

    private fun saveRestoreRect() {
        restoreRect.set(params.x, params.y, params.x + params.width, params.y + params.height)
    }

    private fun setMaximized(value: Boolean) {
        isMaximized = value
        maximizeButton.setImageResource(if (value) R.drawable.ic_restore else R.drawable.ic_maximize)
        maximizeButton.contentDescription =
            context.getString(if (value) R.string.cd_restore else R.string.cd_maximize)
    }

    private fun headerButton(iconRes: Int, descRes: Int, onClick: () -> Unit) = ImageButton(context).apply {
        setImageResource(iconRes)
        setColorFilter(theme.text)
        background = null
        contentDescription = context.getString(descRes)
        setPadding(dp(9f), dp(9f), dp(9f), dp(9f))
        layoutParams = LinearLayout.LayoutParams(dp(40f), dp(40f))
        setOnClickListener { onClick() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(handle: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = dp(6f)
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        if (isMaximized) {
                            // Leave the maximized state and keep the window under the finger.
                            applyRect(restoreRect)
                            setMaximized(false)
                            startX = (e.rawX - params.width / 2f).toInt()
                            startY = params.y
                        }
                    }
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = (startY + dy.toInt()).coerceAtLeast(0)
                        WindowManagerHelper.safeUpdate(context, root, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved && settings.snapEnabled) {
                        val snap = WindowManagerHelper.snapFor(context, e.rawX, e.rawY)
                        if (snap != WindowManagerHelper.Snap.NONE) {
                            saveRestoreRectFrom(startX, startY)
                            applyRect(WindowManagerHelper.rectFor(context, snap))
                            setMaximized(snap == WindowManagerHelper.Snap.MAXIMIZE)
                        }
                    }
                    keepOnScreen()
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    private fun saveRestoreRectFrom(x: Int, y: Int) {
        if (isMaximized) return
        restoreRect.set(x, y, x + params.width, y + params.height)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachResize(handle: View) {
        var downX = 0f
        var downY = 0f
        var startW = 0
        var startH = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startW = params.width
                    startH = params.height
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.width = (startW + (e.rawX - downX).toInt()).coerceAtLeast(dp(180f))
                    params.height = (startH + (e.rawY - downY).toInt()).coerceAtLeast(dp(160f))
                    if (isMaximized) setMaximized(false)
                    WindowManagerHelper.safeUpdate(context, root, params)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    keepOnScreen()
                    true
                }
                else -> false
            }
        }
    }

    private fun animDuration(ms: Long): Long = (ms / settings.animationSpeed).toLong()

    private fun dp(v: Float) = WindowManagerHelper.dp(context, v)

    companion object {
        private const val TAG = "FloatingWindow"
    }
}
