package com.allapps.floatingwindow.core

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.allapps.floatingwindow.data.SettingsRepository
import kotlin.math.roundToInt

/** Overlay window helpers: sizes, layout parameters, focus switching and snapping. */
object WindowManagerHelper {

    enum class Snap { NONE, LEFT_HALF, RIGHT_HALF, BOTTOM_HALF, MAXIMIZE }

    fun windowManager(context: Context): WindowManager =
        context.getSystemService(WindowManager::class.java)

    fun dp(context: Context, value: Float): Int =
        (value * context.resources.displayMetrics.density).roundToInt()

    fun screenSize(context: Context): Point {
        val wm = windowManager(context)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val m = context.resources.displayMetrics
            Point(m.widthPixels, m.heightPixels)
        }
    }

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    fun statusBarHeight(context: Context): Int {
        val id = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) context.resources.getDimensionPixelSize(id) else dp(context, 24f)
    }

    /**
     * Base parameters for an overlay window. Not focusable by default, so the keyboard and the
     * Back button keep working in the app underneath. Touches outside go to the app below.
     */
    fun overlayParams(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        }

    /** Makes a window able (or unable) to receive keyboard input. */
    fun setFocusable(context: Context, view: View, params: WindowManager.LayoutParams, focusable: Boolean) {
        val flag = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val newFlags = if (focusable) params.flags and flag.inv() else params.flags or flag
        if (newFlags == params.flags) return
        params.flags = newFlags
        safeUpdate(context, view, params)
    }

    fun safeUpdate(context: Context, view: View, params: WindowManager.LayoutParams) {
        if (!view.isAttachedToWindow) return
        try {
            windowManager(context).updateViewLayout(view, params)
        } catch (e: IllegalArgumentException) {
            // The view was removed in the meantime.
        }
    }

    /** The default floating window rectangle from the user's size and position settings. */
    fun defaultWindowRect(context: Context, settings: SettingsRepository): Rect {
        val screen = screenSize(context)
        val top = statusBarHeight(context)
        val w = (screen.x * settings.windowWidthPct / 100f).roundToInt()
        val h = ((screen.y - top) * settings.windowHeightPct / 100f).roundToInt()
        val x = ((screen.x - w) * settings.windowXPct / 100f).roundToInt()
        val y = top + ((screen.y - top - h) * settings.windowYPct / 100f).roundToInt()
        return Rect(x, y, x + w, y + h)
    }

    /** Keeps at least part of a window on screen so it can always be grabbed again. */
    fun clamp(context: Context, params: WindowManager.LayoutParams) {
        val screen = screenSize(context)
        val minVisible = dp(context, 64f)
        params.width = params.width.coerceIn(dp(context, 160f), screen.x)
        params.height = params.height.coerceIn(dp(context, 140f), screen.y)
        params.x = params.x.coerceIn(minVisible - params.width, screen.x - minVisible)
        params.y = params.y.coerceIn(0, screen.y - minVisible)
    }

    /** Which snap zone a drag ended in, based on the finger position. */
    fun snapFor(context: Context, rawX: Float, rawY: Float): Snap {
        val screen = screenSize(context)
        val edge = dp(context, 28f)
        return when {
            rawY < statusBarHeight(context) + edge -> Snap.MAXIMIZE
            rawX < edge -> Snap.LEFT_HALF
            rawX > screen.x - edge -> Snap.RIGHT_HALF
            rawY > screen.y - edge * 2 -> Snap.BOTTOM_HALF
            else -> Snap.NONE
        }
    }

    fun rectFor(context: Context, snap: Snap): Rect {
        val screen = screenSize(context)
        val top = statusBarHeight(context)
        return when (snap) {
            Snap.LEFT_HALF -> Rect(0, top, screen.x / 2, screen.y)
            Snap.RIGHT_HALF -> Rect(screen.x / 2, top, screen.x, screen.y)
            Snap.BOTTOM_HALF -> Rect(0, top + (screen.y - top) / 2, screen.x, screen.y)
            Snap.MAXIMIZE, Snap.NONE -> Rect(0, top, screen.x, screen.y)
        }
    }
}
