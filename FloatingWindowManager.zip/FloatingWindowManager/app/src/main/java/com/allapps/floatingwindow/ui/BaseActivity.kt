package com.allapps.floatingwindow.ui

import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.service.FloatingSidebarService
import com.allapps.floatingwindow.service.FloatingWindowService
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

/** Shared helpers for every screen. */
abstract class BaseActivity : AppCompatActivity() {

    protected val settings: SettingsRepository by lazy { SettingsRepository(this) }

    protected fun setupToolbar(@StringRes title: Int) {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setTitle(title)
        toolbar.setNavigationOnClickListener { finish() }
    }

    protected fun open(target: Class<*>) {
        startActivity(Intent(this, target))
    }

    protected fun toast(@StringRes text: Int) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    /** Tells running services to apply changed settings. */
    protected fun refreshServices() {
        if (FloatingWindowService.isRunning) FloatingWindowService.send(this, FloatingWindowService.ACTION_REFRESH)
        if (FloatingSidebarService.isRunning) FloatingSidebarService.send(this, FloatingSidebarService.ACTION_REFRESH)
    }

    protected fun addSection(container: LinearLayout, @StringRes label: Int) {
        val tv = layoutInflater.inflate(R.layout.item_section_label, container, false) as TextView
        tv.setText(label)
        container.addView(tv)
    }

    /** Adds a rounded card and returns it, so rows can be added inside. */
    protected fun addCard(container: LinearLayout): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, pad / 2)
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = (10 * resources.displayMetrics.density).toInt()
        container.addView(card, lp)
        return card
    }

    protected fun addSwitchRow(
        container: LinearLayout, @StringRes title: Int, @StringRes desc: Int,
        checked: Boolean, onChange: (Boolean) -> Unit
    ): MaterialSwitch {
        val row = layoutInflater.inflate(R.layout.item_switch_row, container, false)
        row.findViewById<TextView>(R.id.row_title).setText(title)
        row.findViewById<TextView>(R.id.row_desc).setText(desc)
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.isChecked = checked
        sw.contentDescription = getString(title)
        sw.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return sw
    }

    protected fun addSliderRow(
        container: LinearLayout, @StringRes label: Int,
        from: Float, to: Float, step: Float, value: Float,
        format: (Float) -> String, onChange: (Float) -> Unit
    ): Slider {
        val row = layoutInflater.inflate(R.layout.item_slider_row, container, false)
        row.findViewById<TextView>(R.id.slider_label).setText(label)
        val valueText = row.findViewById<TextView>(R.id.slider_value)
        val slider = row.findViewById<Slider>(R.id.slider)
        slider.valueFrom = from
        slider.valueTo = to
        slider.stepSize = step
        // The value must sit exactly on a step, otherwise the Slider throws an exception.
        val steps = ((value.coerceIn(from, to) - from) / step).roundToInt()
        slider.value = (from + steps * step).coerceIn(from, to)
        slider.contentDescription = getString(label)
        valueText.text = format(slider.value)
        slider.setLabelFormatter { format(it) }
        slider.addOnChangeListener { _, v, fromUser ->
            valueText.text = format(v)
            if (fromUser) onChange(v)
        }
        container.addView(row)
        return slider
    }

    /** A title with a single-choice chip group underneath. */
    protected fun <T> addChoiceRow(
        container: LinearLayout, @StringRes title: Int, items: List<T>,
        label: (T) -> String, selected: T, onSelect: (T) -> Unit
    ) {
        val row = layoutInflater.inflate(R.layout.item_chip_group_row, container, false)
        row.findViewById<TextView>(R.id.chip_row_title).setText(title)
        bindChips(row.findViewById(R.id.chip_row_group), items, label, selected, onSelect)
        container.addView(row)
    }

    protected fun <T> bindChips(
        group: ChipGroup, items: List<T>, label: (T) -> String, selected: T, onSelect: (T) -> Unit
    ) {
        group.setOnCheckedStateChangeListener(null)
        group.removeAllViews()
        items.forEach { item ->
            val chip = layoutInflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.id = View.generateViewId()
            chip.text = label(item)
            chip.tag = item
            group.addView(chip)
            if (item == selected) group.check(chip.id)
        }
        group.setOnCheckedStateChangeListener { g, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            val chip = g.findViewById<Chip>(id) ?: return@setOnCheckedStateChangeListener
            @Suppress("UNCHECKED_CAST")
            onSelect(chip.tag as T)
        }
    }

    protected fun pct(v: Float): String = getString(R.string.value_percent, v.roundToInt())
    protected fun dpText(v: Float): String = getString(R.string.value_dp, v.roundToInt())
}
