package com.allapps.floatingwindow.core

import android.app.ActivityOptions
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.data.AppInfo
import com.allapps.floatingwindow.data.ApplicationRepository
import com.allapps.floatingwindow.data.LaunchMode
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.data.WindowSupport

/**
 * Opens installed apps using only public Android APIs:
 * - Full screen: a normal launch.
 * - Floating window: ActivityOptions.setLaunchBounds, which Android honors only when the
 *   system offers freeform windows to other apps and the app supports resizing.
 * - Side by side: Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT, which works while split screen is active.
 * When a mode is not available, the app opens in full screen and a short message explains why.
 */
object AppLauncher {

    private const val TAG = "AppLauncher"

    enum class Result { FULL_SCREEN, WINDOW_REQUESTED, SIDE_BY_SIDE_REQUESTED, FAILED }

    /** The mode used when the user simply taps an app. */
    fun defaultMode(context: Context, settings: SettingsRepository): LaunchMode =
        settings.launchModeOrNull
            ?: if (DeviceCapabilities.detect(context).freeformAvailable) LaunchMode.FLOATING_WINDOW
            else LaunchMode.FULL_SCREEN

    fun launch(context: Context, app: AppInfo, mode: LaunchMode, quiet: Boolean = false): Result {
        val settings = SettingsRepository(context)
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.packageName, app.activityName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

        val result: Result = when (mode) {
            LaunchMode.FULL_SCREEN -> if (start(context, intent, null)) Result.FULL_SCREEN else Result.FAILED

            LaunchMode.FLOATING_WINDOW -> {
                val caps = DeviceCapabilities.detect(context)
                when {
                    !caps.freeformAvailable -> {
                        val ok = start(context, intent, null)
                        if (ok && !quiet) toast(context, context.getString(R.string.toast_window_no_device, app.label))
                        if (ok) Result.FULL_SCREEN else Result.FAILED
                    }
                    app.windowSupport == WindowSupport.UNLIKELY -> {
                        val ok = start(context, intent, null)
                        if (ok && !quiet) toast(context, context.getString(R.string.toast_window_no_app, app.label))
                        if (ok) Result.FULL_SCREEN else Result.FAILED
                    }
                    else -> {
                        val bounds = WindowManagerHelper.defaultWindowRect(context, settings)
                        val options = ActivityOptions.makeBasic().setLaunchBounds(bounds)
                        val ok = start(context, intent, options.toBundle())
                        if (ok && !quiet) toast(context, context.getString(R.string.toast_window_requested, app.label))
                        if (ok) Result.WINDOW_REQUESTED else Result.FAILED
                    }
                }
            }

            LaunchMode.SIDE_BY_SIDE -> {
                intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                val ok = start(context, intent, null)
                if (ok && !quiet) toast(context, context.getString(R.string.toast_side_by_side, app.label))
                if (ok) Result.SIDE_BY_SIDE_REQUESTED else Result.FAILED
            }
        }

        if (result == Result.FAILED) {
            toast(context, context.getString(R.string.toast_open_failed, app.label))
            ApplicationRepository.invalidate()
        } else {
            settings.addRecent(app.key)
        }
        return result
    }

    /** Explains, in plain English, whether this app can open in a floating window. */
    fun explainSupport(context: Context, app: AppInfo): String {
        val caps = DeviceCapabilities.detect(context)
        return when {
            !caps.freeformAvailable -> context.getString(R.string.why_no_device)
            app.windowSupport == WindowSupport.UNLIKELY -> context.getString(R.string.why_no_app, app.label)
            else -> context.getString(R.string.why_maybe, app.label)
        }
    }

    fun openAppInfo(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        start(context, intent, null)
    }

    /** Opens any intent from an activity, a service or an overlay. */
    fun start(context: Context, intent: Intent, options: android.os.Bundle?): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent, options)
        true
    } catch (e: ActivityNotFoundException) {
        Log.w(TAG, "Activity not found", e)
        false
    } catch (e: SecurityException) {
        Log.w(TAG, "Not allowed to open activity", e)
        false
    }

    private fun toast(context: Context, text: String) {
        Toast.makeText(context.applicationContext, text, Toast.LENGTH_LONG).show()
    }
}
