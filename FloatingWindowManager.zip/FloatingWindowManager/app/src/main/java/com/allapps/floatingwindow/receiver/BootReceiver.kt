package com.allapps.floatingwindow.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.service.FloatingSidebarService
import com.allapps.floatingwindow.service.FloatingWindowService

/** Brings back the floating button and sidebar after a restart, if the user wants that. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val settings = SettingsRepository(context)
        if (!settings.startOnBoot && action == Intent.ACTION_BOOT_COMPLETED) return
        if (settings.bubbleEnabled) FloatingWindowService.send(context, FloatingWindowService.ACTION_START)
        if (settings.sidebarEnabled) FloatingSidebarService.send(context, FloatingSidebarService.ACTION_START)
    }
}
