package com.allapps.floatingwindow.ui

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.DeviceCapabilities
import com.allapps.floatingwindow.core.PermissionManager
import com.allapps.floatingwindow.service.FloatingSidebarService
import com.allapps.floatingwindow.service.FloatingWindowService
import com.google.android.material.materialswitch.MaterialSwitch

/** Home dashboard: status, floating tool switches, quick open, device support and navigation. */
class MainActivity : BaseActivity() {

    private lateinit var statusText: TextView
    private lateinit var setupCard: View
    private lateinit var bubbleSwitch: MaterialSwitch
    private lateinit var sidebarSwitch: MaterialSwitch
    private var updating = false

    private data class NavItem(
        @DrawableRes val icon: Int, val tintRes: Int,
        @StringRes val title: Int, @StringRes val desc: Int, val target: Class<*>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.status_text)
        setupCard = findViewById(R.id.card_setup)

        findViewById<View>(R.id.btn_finish_setup).setOnClickListener { open(PermissionActivity::class.java) }

        val toggles = findViewById<LinearLayout>(R.id.toggle_container)
        bubbleSwitch = addSwitchRow(toggles, R.string.sw_bubble, R.string.sw_bubble_desc, settings.bubbleEnabled) {
            if (!updating) onBubbleChanged(it)
        }
        sidebarSwitch = addSwitchRow(toggles, R.string.sw_sidebar, R.string.sw_sidebar_desc, settings.sidebarEnabled) {
            if (!updating) onSidebarChanged(it)
        }

        findViewById<View>(R.id.btn_quick_launcher).setOnClickListener { openTool(FloatingWindowService.ACTION_SHOW_LAUNCHER) }
        findViewById<View>(R.id.btn_quick_calculator).setOnClickListener { openTool(FloatingWindowService.ACTION_OPEN_CALCULATOR) }
        findViewById<View>(R.id.btn_quick_notes).setOnClickListener { openTool(FloatingWindowService.ACTION_OPEN_NOTES) }

        buildNavigation()
    }

    override fun onResume() {
        super.onResume()
        val canDraw = PermissionManager.canDrawOverlays(this)
        if (canDraw) {
            if (settings.bubbleEnabled && !FloatingWindowService.isRunning) {
                FloatingWindowService.send(this, FloatingWindowService.ACTION_START)
            }
            if (settings.sidebarEnabled && !FloatingSidebarService.isRunning) {
                FloatingSidebarService.send(this, FloatingSidebarService.ACTION_START)
            }
        }
        statusText.setText(if (canDraw) R.string.status_ready else R.string.status_needs_overlay)
        setupCard.visibility = if (canDraw) View.GONE else View.VISIBLE
        updating = true
        bubbleSwitch.isChecked = settings.bubbleEnabled && canDraw
        sidebarSwitch.isChecked = settings.sidebarEnabled && canDraw
        updating = false
        showCapabilities()
    }

    private fun onBubbleChanged(on: Boolean) {
        if (on && !PermissionManager.canDrawOverlays(this)) {
            setSwitch(bubbleSwitch, false)
            toast(R.string.needs_overlay_toast)
            open(PermissionActivity::class.java)
            return
        }
        settings.bubbleEnabled = on
        if (on) FloatingWindowService.send(this, FloatingWindowService.ACTION_START)
        else if (FloatingWindowService.isRunning) FloatingWindowService.send(this, FloatingWindowService.ACTION_REFRESH)
    }

    private fun onSidebarChanged(on: Boolean) {
        if (on && !PermissionManager.canDrawOverlays(this)) {
            setSwitch(sidebarSwitch, false)
            toast(R.string.needs_overlay_toast)
            open(PermissionActivity::class.java)
            return
        }
        settings.sidebarEnabled = on
        if (on) FloatingSidebarService.send(this, FloatingSidebarService.ACTION_START)
        else FloatingSidebarService.stop(this)
    }

    private fun openTool(action: String) {
        if (!FloatingWindowService.send(this, action)) {
            toast(R.string.needs_overlay_toast)
            open(PermissionActivity::class.java)
        }
    }

    private fun setSwitch(sw: MaterialSwitch, checked: Boolean) {
        updating = true
        sw.isChecked = checked
        updating = false
    }

    private fun showCapabilities() {
        val caps = DeviceCapabilities.detect(this)
        val lines = mutableListOf(
            getString(R.string.cap_device, caps.manufacturer, caps.model),
            getString(R.string.cap_android, caps.androidVersion, caps.sdk),
            getString(R.string.cap_build, caps.systemBuild),
            getString(if (caps.freeformAvailable) R.string.cap_freeform_yes else R.string.cap_freeform_no),
            getString(R.string.cap_split),
            getString(if (caps.pictureInPicture) R.string.cap_pip_yes else R.string.cap_pip_no),
            getString(R.string.cap_overlay)
        )
        if (caps.isXiaomi) lines.add(getString(R.string.cap_xiaomi))
        val container = findViewById<LinearLayout>(R.id.capability_container)
        container.removeAllViews()
        lines.forEach { line ->
            val tv = layoutInflater.inflate(R.layout.item_text_line, container, false) as TextView
            tv.text = line
            container.addView(tv)
        }
    }

    private fun buildNavigation() {
        val items = listOf(
            NavItem(R.drawable.ic_apps, R.color.accent, R.string.nav_all_apps, R.string.nav_all_apps_desc, AllAppsActivity::class.java),
            NavItem(R.drawable.ic_star, R.color.accent_amber, R.string.nav_favorites, R.string.nav_favorites_desc, FavoritesActivity::class.java),
            NavItem(R.drawable.ic_clock, R.color.accent_2, R.string.nav_recent, R.string.nav_recent_desc, RecentAppsActivity::class.java),
            NavItem(R.drawable.ic_sidebar, R.color.accent_pink, R.string.nav_sidebar, R.string.nav_sidebar_desc, SidebarSettingsActivity::class.java),
            NavItem(R.drawable.ic_windows, R.color.accent_green, R.string.nav_window, R.string.nav_window_desc, WindowSettingsActivity::class.java),
            NavItem(R.drawable.ic_palette, R.color.accent_amber, R.string.nav_appearance, R.string.nav_appearance_desc, AppearanceActivity::class.java),
            NavItem(R.drawable.ic_shield, R.color.accent_red, R.string.nav_permissions, R.string.nav_permissions_desc, PermissionActivity::class.java),
            NavItem(R.drawable.ic_info, R.color.text_secondary, R.string.nav_help, R.string.nav_help_desc, HelpActivity::class.java)
        )
        val container = findViewById<LinearLayout>(R.id.nav_container)
        items.forEach { item ->
            val card = layoutInflater.inflate(R.layout.item_nav_card, container, false)
            val icon = card.findViewById<ImageView>(R.id.nav_icon)
            icon.setImageResource(item.icon)
            icon.backgroundTintList = ColorStateList.valueOf(getColor(item.tintRes))
            icon.imageTintList = ColorStateList.valueOf(getColor(R.color.on_accent))
            card.findViewById<TextView>(R.id.nav_title).setText(item.title)
            card.findViewById<TextView>(R.id.nav_desc).setText(item.desc)
            card.setOnClickListener { open(item.target) }
            container.addView(card)
        }
    }
}
