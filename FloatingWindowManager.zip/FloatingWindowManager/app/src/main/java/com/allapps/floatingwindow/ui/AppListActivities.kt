package com.allapps.floatingwindow.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.AppLauncher
import com.allapps.floatingwindow.data.AppInfo
import com.allapps.floatingwindow.data.ApplicationRepository
import com.allapps.floatingwindow.data.LaunchMode
import com.allapps.floatingwindow.data.WindowSupport
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Shared screen for All Apps, Favorite Apps and Recent Apps. */
abstract class AppListActivity : BaseActivity() {

    protected enum class Filter(@StringRes val label: Int) {
        ALL(R.string.filter_all), POPULAR(R.string.filter_popular),
        USER(R.string.filter_user), SYSTEM(R.string.filter_system)
    }

    @get:StringRes
    protected abstract val titleRes: Int

    @get:StringRes
    protected abstract val emptyRes: Int
    protected open val showFilters = false
    protected open val reorderable = false

    /** Picks and orders the apps this screen shows. */
    protected abstract fun select(apps: List<AppInfo>): List<AppInfo>

    protected open fun setUpExtras(note: TextView, action: MaterialButton) = Unit

    private lateinit var search: EditText
    private lateinit var emptyText: TextView
    private lateinit var progress: ProgressBar
    private val adapter by lazy { AppListAdapter() }
    private var allApps: List<AppInfo> = emptyList()
    private var filter = Filter.ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)
        setupToolbar(titleRes)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.menu.add(0, MENU_REFRESH, 0, R.string.refresh).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == MENU_REFRESH) load(force = true)
            true
        }

        search = findViewById(R.id.search_box)
        emptyText = findViewById(R.id.empty_text)
        progress = findViewById(R.id.progress)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) = refresh()
        })

        val filterScroll = findViewById<View>(R.id.filter_scroll)
        if (showFilters) {
            bindChips(findViewById<ChipGroup>(R.id.filter_chips), Filter.entries, { getString(it.label) }, filter) {
                filter = it
                refresh()
            }
        } else {
            filterScroll.visibility = View.GONE
        }
        setUpExtras(findViewById(R.id.list_note), findViewById(R.id.list_action))

        val list = findViewById<RecyclerView>(R.id.app_list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        load(force = false)
    }

    private fun load(force: Boolean) {
        progress.visibility = View.VISIBLE
        ApplicationRepository.load(this, force) { apps ->
            if (isDestroyed) return@load
            progress.visibility = View.GONE
            allApps = apps
            refresh()
        }
    }

    protected fun refresh() {
        val query = search.text?.toString()?.trim().orEmpty()
        var items = select(allApps)
        items = when (filter) {
            Filter.ALL -> items
            Filter.POPULAR -> items.filter { it.isPopular }
            Filter.USER -> items.filter { !it.isSystem }
            Filter.SYSTEM -> items.filter { it.isSystem }
        }
        if (query.isNotEmpty()) items = items.filter { it.label.contains(query, ignoreCase = true) }
        adapter.submit(items)
        val showEmpty = items.isEmpty() && progress.visibility != View.VISIBLE
        emptyText.visibility = if (showEmpty) View.VISIBLE else View.GONE
        emptyText.setText(if (query.isNotEmpty()) R.string.empty_search else emptyRes)
    }

    private fun launch(app: AppInfo, mode: LaunchMode) {
        AppLauncher.launch(this, app, mode)
    }

    private fun showOptions(app: AppInfo, anchor: View) {
        val menu = PopupMenu(this, anchor)
        val favorite = settings.isFavorite(app.key)
        menu.menu.add(0, 1, 0, R.string.action_open_full)
        menu.menu.add(0, 2, 1, R.string.action_open_window)
        menu.menu.add(0, 3, 2, R.string.action_open_side)
        menu.menu.add(0, 4, 3, if (favorite) R.string.action_remove_favorite else R.string.action_add_favorite)
        menu.menu.add(0, 5, 4, R.string.action_app_info)
        menu.menu.add(0, 6, 5, R.string.action_why)
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> launch(app, LaunchMode.FULL_SCREEN)
                2 -> launch(app, LaunchMode.FLOATING_WINDOW)
                3 -> launch(app, LaunchMode.SIDE_BY_SIDE)
                4 -> {
                    settings.toggleFavorite(app.key)
                    refresh()
                }
                5 -> AppLauncher.openAppInfo(this, app.packageName)
                6 -> MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.why_title)
                    .setMessage(AppLauncher.explainSupport(this, app))
                    .setPositiveButton(R.string.ok, null)
                    .show()
            }
            true
        }
        menu.show()
    }

    private inner class AppListAdapter : RecyclerView.Adapter<AppListAdapter.Holder>() {
        private var items: List<AppInfo> = emptyList()

        @SuppressLint("NotifyDataSetChanged")
        fun submit(newItems: List<AppInfo>) {
            items = newItems
            notifyDataSetChanged()
        }

        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.app_icon)
            val name: TextView = view.findViewById(R.id.app_name)
            val support: TextView = view.findViewById(R.id.app_support)
            val favorite: ImageButton = view.findViewById(R.id.btn_favorite)
            val more: ImageButton = view.findViewById(R.id.btn_more)
            val up: ImageButton = view.findViewById(R.id.btn_up)
            val down: ImageButton = view.findViewById(R.id.btn_down)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
            Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val app = items[position]
            holder.icon.setImageDrawable(app.icon)
            holder.name.text = app.label
            val likely = app.windowSupport == WindowSupport.LIKELY
            holder.support.setText(if (likely) R.string.support_likely else R.string.support_unlikely)
            holder.support.setTextColor(getColor(if (likely) R.color.accent_green else R.color.accent_amber))

            val fav = settings.isFavorite(app.key)
            holder.favorite.setImageResource(if (fav) R.drawable.ic_star else R.drawable.ic_star_outline)
            holder.favorite.contentDescription =
                getString(if (fav) R.string.cd_favorite_remove else R.string.cd_favorite_add, app.label)
            holder.favorite.setOnClickListener {
                settings.toggleFavorite(app.key)
                refresh()
            }
            holder.more.contentDescription = getString(R.string.cd_more_options, app.label)
            holder.more.setOnClickListener { showOptions(app, holder.more) }

            holder.up.visibility = if (reorderable) View.VISIBLE else View.GONE
            holder.down.visibility = if (reorderable) View.VISIBLE else View.GONE
            holder.up.contentDescription = getString(R.string.cd_move_up, app.label)
            holder.down.contentDescription = getString(R.string.cd_move_down, app.label)
            holder.up.setOnClickListener {
                settings.moveFavorite(app.key, -1)
                refresh()
            }
            holder.down.setOnClickListener {
                settings.moveFavorite(app.key, 1)
                refresh()
            }

            holder.itemView.setOnClickListener { launch(app, AppLauncher.defaultMode(this@AppListActivity, settings)) }
            holder.itemView.setOnLongClickListener {
                showOptions(app, holder.more)
                true
            }
        }

        override fun getItemCount() = items.size
    }

    companion object {
        private const val MENU_REFRESH = 1
    }
}

class AllAppsActivity : AppListActivity() {
    override val titleRes = R.string.all_apps_title
    override val emptyRes = R.string.empty_search
    override val showFilters = true
    override fun select(apps: List<AppInfo>) = apps
}

class FavoritesActivity : AppListActivity() {
    override val titleRes = R.string.favorites_title
    override val emptyRes = R.string.empty_favorites
    override val reorderable = true
    override fun select(apps: List<AppInfo>) =
        settings.favorites.mapNotNull { key -> apps.firstOrNull { it.key == key } }
}

class RecentAppsActivity : AppListActivity() {
    override val titleRes = R.string.recent_title
    override val emptyRes = R.string.empty_recent
    override fun select(apps: List<AppInfo>) =
        settings.recents.mapNotNull { key -> apps.firstOrNull { it.key == key } }

    override fun setUpExtras(note: TextView, action: MaterialButton) {
        note.visibility = View.VISIBLE
        note.setText(R.string.recent_note)
        action.visibility = View.VISIBLE
        action.setText(R.string.clear_recent)
        action.setOnClickListener {
            settings.clearRecents()
            refresh()
        }
    }
}
