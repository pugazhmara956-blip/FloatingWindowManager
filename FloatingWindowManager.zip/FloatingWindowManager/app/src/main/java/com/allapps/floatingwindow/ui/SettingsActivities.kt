package com.allapps.floatingwindow.ui

import android.os.Bundle
import android.widget.LinearLayout
import androidx.annotation.StringRes
import com.allapps.floatingwindow.FloatingApp
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.AppLauncher
import com.allapps.floatingwindow.core.PermissionManager
import com.allapps.floatingwindow.data.LaunchMode
import com.allapps.floatingwindow.data.SidebarSide
import com.allapps.floatingwindow.data.ThemeMode
import com.allapps.floatingwindow.service.FloatingSidebarService
import com.allapps.floatingwindow.service.FloatingWindowService
import com.google.android.material.button.MaterialButton
import kotlin.math.roundToInt

/** Base for settings screens built from rows inside a scrolling container. */
abstract class ContainerActivity : BaseActivity() {
    @get:StringRes
    protected abstract val titleRes: Int

    protected lateinit var container: LinearLayout

    protected abstract fun build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_container)
        setupToolbar(titleRes)
        container = findViewById(R.id.container)
        build()
    }

    protected fun addButton(@StringRes label: Int, outlined: Boolean = false, onClick: () -> Unit) {
        val style = if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
        else com.google.android.material.R.attr.materialButtonStyle
        val button = MaterialButton(this, null, style).apply {
            setText(label)
            cornerRadius = (16 * resources.displayMetrics.density).toInt()
            setOnClickListener { onClick() }
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = (16 * resources.displayMetrics.density).toInt()
        container.addView(button, lp)
    }
}

/** Floating sidebar settings. */
class SidebarSettingsActivity : ContainerActivity() {
    override val titleRes = R.string.sidebar_settings_title

    override fun build() {
        val main = addCard(container)
        addSwitchRow(main, R.string.sw_sidebar_enabled, R.string.sw_sidebar_enabled_desc, settings.sidebarEnabled) { on ->
            if (on && !PermissionManager.canDrawOverlays(this)) {
                toast(R.string.needs_overlay_toast)
                open(PermissionActivity::class.java)
                return@addSwitchRow
            }
            settings.sidebarEnabled = on
            if (on) FloatingSidebarService.send(this, FloatingSidebarService.ACTION_START)
            else FloatingSidebarService.stop(this)
        }

        addSection(container, R.string.sidebar_side)
        val position = addCard(container)
        addChoiceRow(position, R.string.sidebar_side, SidebarSide.entries, {
            getString(if (it == SidebarSide.LEFT) R.string.side_left else R.string.side_right)
        }, settings.sidebarSide) {
            settings.sidebarSide = it
            refreshServices()
        }
        addSliderRow(position, R.string.handle_position, 5f, 85f, 1f, settings.sidebarOffsetPct.toFloat(), this::pct) {
            settings.sidebarOffsetPct = it.roundToInt()
            refreshServices()
        }
        addSliderRow(position, R.string.sidebar_transparency, 40f, 100f, 1f, settings.sidebarOpacity.toFloat(), this::pct) {
            settings.sidebarOpacity = it.roundToInt()
        }

        addSection(container, R.string.sidebar_sections)
        val sections = addCard(container)
        addSwitchRow(sections, R.string.sw_show_favorites, R.string.sw_show_favorites_desc, settings.sidebarShowFavorites) {
            settings.sidebarShowFavorites = it
        }
        addSwitchRow(sections, R.string.sw_show_recent, R.string.sw_show_recent_desc, settings.sidebarShowRecent) {
            settings.sidebarShowRecent = it
        }
        addSwitchRow(sections, R.string.sw_show_tools, R.string.sw_show_tools_desc, settings.sidebarShowTools) {
            settings.sidebarShowTools = it
        }
        addSwitchRow(sections, R.string.sw_show_quick, R.string.sw_show_quick_desc, settings.sidebarShowQuickSettings) {
            settings.sidebarShowQuickSettings = it
        }

        addButton(R.string.open_sidebar_now) {
            if (!FloatingSidebarService.send(this, FloatingSidebarService.ACTION_OPEN)) {
                toast(R.string.needs_overlay_toast)
                open(PermissionActivity::class.java)
            }
        }
    }
}

/** Floating window size, position, opacity, snapping and launch mode. */
class WindowSettingsActivity : ContainerActivity() {
    override val titleRes = R.string.window_settings_title

    override fun build() {
        addSection(container, R.string.window_size)
        val size = addCard(container)
        addSliderRow(size, R.string.window_width, 40f, 100f, 1f, settings.windowWidthPct.toFloat(), this::pct) {
            settings.windowWidthPct = it.roundToInt()
        }
        addSliderRow(size, R.string.window_height, 30f, 90f, 1f, settings.windowHeightPct.toFloat(), this::pct) {
            settings.windowHeightPct = it.roundToInt()
        }

        addSection(container, R.string.window_position)
        val position = addCard(container)
        addSliderRow(position, R.string.window_x, 0f, 100f, 1f, settings.windowXPct.toFloat(), this::pct) {
            settings.windowXPct = it.roundToInt()
        }
        addSliderRow(position, R.string.window_y, 0f, 100f, 1f, settings.windowYPct.toFloat(), this::pct) {
            settings.windowYPct = it.roundToInt()
        }

        addSection(container, R.string.window_opacity)
        val look = addCard(container)
        addSliderRow(look, R.string.window_opacity, 40f, 100f, 1f, settings.windowOpacity.toFloat(), this::pct) {
            settings.windowOpacity = it.roundToInt()
            refreshServices()
        }
        addSwitchRow(look, R.string.sw_snap, R.string.sw_snap_desc, settings.snapEnabled) {
            settings.snapEnabled = it
        }

        addSection(container, R.string.default_launch_mode)
        val modes = addCard(container)
        addChoiceRow(modes, R.string.default_launch_mode, LaunchMode.entries, {
            getString(
                when (it) {
                    LaunchMode.FULL_SCREEN -> R.string.mode_full
                    LaunchMode.FLOATING_WINDOW -> R.string.mode_window
                    LaunchMode.SIDE_BY_SIDE -> R.string.mode_side
                }
            )
        }, AppLauncher.defaultMode(this, settings)) {
            settings.launchModeOrNull = it
        }
        addSwitchRow(modes, R.string.sw_boot, R.string.sw_boot_desc, settings.startOnBoot) {
            settings.startOnBoot = it
        }
        container.addView(layoutInflater.inflate(R.layout.item_text_line, container, false).apply {
            (this as android.widget.TextView).setText(R.string.launch_mode_note)
        })

        addButton(R.string.test_window) {
            if (!FloatingWindowService.send(this, FloatingWindowService.ACTION_OPEN_TEST)) {
                toast(R.string.needs_overlay_toast)
                open(PermissionActivity::class.java)
            }
        }
    }
}

/** Theme, corner radius, animation speed and floating button size. */
class AppearanceActivity : ContainerActivity() {
    override val titleRes = R.string.appearance_title

    override fun build() {
        val themeCard = addCard(container)
        addChoiceRow(themeCard, R.string.theme, ThemeMode.entries, {
            getString(
                when (it) {
                    ThemeMode.SYSTEM -> R.string.theme_system
                    ThemeMode.DARK -> R.string.theme_dark
                    ThemeMode.LIGHT -> R.string.theme_light
                }
            )
        }, settings.themeMode) {
            settings.themeMode = it
            FloatingApp.applyTheme(it)
            refreshServices()
        }

        val shape = addCard(container)
        addSliderRow(shape, R.string.corner_radius, 0f, 32f, 1f, settings.cornerRadiusDp.toFloat(), this::dpText) {
            settings.cornerRadiusDp = it.roundToInt()
            refreshServices()
        }
        addSliderRow(shape, R.string.animation_speed, 5f, 20f, 1f, settings.animationSpeed * 10f, {
            getString(R.string.value_speed, it / 10f)
        }) {
            settings.animationSpeed = it / 10f
        }
        addSliderRow(shape, R.string.bubble_size, 40f, 72f, 2f, settings.bubbleSizeDp.toFloat(), this::dpText) {
            settings.bubbleSizeDp = it.roundToInt()
            refreshServices()
        }
    }
}
