package com.allapps.floatingwindow.overlay

import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.data.ThemeMode

/** Colors for overlay windows, which are drawn outside the activities' themes. */
class OverlayTheme(val dark: Boolean) {

    val windowBg = if (dark) 0xFF17162A.toInt() else 0xFFFFFFFF.toInt()
    val headerBg = if (dark) 0xFF231F40.toInt() else 0xFFF1EEFF.toInt()
    val stroke = if (dark) 0xFF34305A.toInt() else 0xFFDDD6F7.toInt()
    val text = if (dark) 0xFFFFFFFF.toInt() else 0xFF1E1B2E.toInt()
    val textSecondary = if (dark) 0xFFB6B3CC.toInt() else 0xFF5B5770.toInt()
    val accent = if (dark) 0xFF8B6CFF.toInt() else 0xFF6D4AFF.toInt()
    val accent2 = if (dark) 0xFF38BDF8.toInt() else 0xFF0EA5E9.toInt()
    val keyBg = if (dark) 0xFF2A2748.toInt() else 0xFFF1EEFF.toInt()
    val fieldBg = if (dark) 0xFF201D38.toInt() else 0xFFF7F5FF.toInt()
    val onAccent = 0xFFFFFFFF.toInt()

    /** A context with a matching system theme, so text fields and menus look right. */
    fun themedContext(base: Context): Context = ContextThemeWrapper(
        base,
        if (dark) android.R.style.Theme_DeviceDefault else android.R.style.Theme_DeviceDefault_Light
    )

    fun rounded(color: Int, radiusPx: Float, strokePx: Int = 0, strokeColor: Int = stroke) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(color)
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun accentGradient() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accent2)
    ).apply { shape = GradientDrawable.OVAL }

    companion object {
        fun from(context: Context, settings: SettingsRepository): OverlayTheme {
            val dark = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> (context.resources.configuration.uiMode and
                    Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            }
            return OverlayTheme(dark)
        }
    }
}
