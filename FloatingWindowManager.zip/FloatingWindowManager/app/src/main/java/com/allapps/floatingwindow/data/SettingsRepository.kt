package com.allapps.floatingwindow.data

import android.content.Context
import android.content.SharedPreferences

enum class ThemeMode { SYSTEM, DARK, LIGHT }

enum class LaunchMode { FULL_SCREEN, FLOATING_WINDOW, SIDE_BY_SIDE }

enum class SidebarSide { LEFT, RIGHT }

/** Every setting, favorite, recent app and note is stored locally with SharedPreferences. */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("floating_settings", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = prefs.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun int(key: String, def: Int) = prefs.getInt(key, def)
    private fun putInt(key: String, v: Int) = prefs.edit().putInt(key, v).apply()
    private inline fun <reified T : Enum<T>> enumValue(key: String, def: T): T {
        val name = prefs.getString(key, null) ?: return def
        return enumValues<T>().firstOrNull { it.name == name } ?: def
    }
    private fun putEnum(key: String, v: Enum<*>) = prefs.edit().putString(key, v.name).apply()

    // ---- Appearance ----
    var themeMode: ThemeMode
        get() = enumValue("theme_mode", ThemeMode.DARK)
        set(v) = putEnum("theme_mode", v)

    var animationSpeed: Float
        get() = prefs.getFloat("animation_speed", 1f).coerceIn(0.5f, 2f)
        set(v) = prefs.edit().putFloat("animation_speed", v).apply()

    var cornerRadiusDp: Int
        get() = int("corner_radius", 20).coerceIn(0, 32)
        set(v) = putInt("corner_radius", v)

    var bubbleSizeDp: Int
        get() = int("bubble_size", 56).coerceIn(40, 72)
        set(v) = putInt("bubble_size", v)

    // ---- Floating button and windows ----
    var bubbleEnabled: Boolean
        get() = bool("bubble_enabled", false)
        set(v) = putBool("bubble_enabled", v)

    var windowWidthPct: Int
        get() = int("window_width", 86).coerceIn(40, 100)
        set(v) = putInt("window_width", v)

    var windowHeightPct: Int
        get() = int("window_height", 55).coerceIn(30, 90)
        set(v) = putInt("window_height", v)

    var windowXPct: Int
        get() = int("window_x", 50).coerceIn(0, 100)
        set(v) = putInt("window_x", v)

    var windowYPct: Int
        get() = int("window_y", 35).coerceIn(0, 100)
        set(v) = putInt("window_y", v)

    var windowOpacity: Int
        get() = int("window_opacity", 100).coerceIn(40, 100)
        set(v) = putInt("window_opacity", v)

    var snapEnabled: Boolean
        get() = bool("snap_enabled", true)
        set(v) = putBool("snap_enabled", v)

    /** Null means "not chosen yet": the app picks the best mode for this phone. */
    var launchModeOrNull: LaunchMode?
        get() = prefs.getString("launch_mode", null)?.let { n -> LaunchMode.entries.firstOrNull { it.name == n } }
        set(v) {
            if (v == null) prefs.edit().remove("launch_mode").apply() else putEnum("launch_mode", v)
        }

    var startOnBoot: Boolean
        get() = bool("start_on_boot", true)
        set(v) = putBool("start_on_boot", v)

    // ---- Sidebar ----
    var sidebarEnabled: Boolean
        get() = bool("sidebar_enabled", false)
        set(v) = putBool("sidebar_enabled", v)

    var sidebarSide: SidebarSide
        get() = enumValue("sidebar_side", SidebarSide.RIGHT)
        set(v) = putEnum("sidebar_side", v)

    var sidebarOffsetPct: Int
        get() = int("sidebar_offset", 35).coerceIn(5, 85)
        set(v) = putInt("sidebar_offset", v)

    var sidebarOpacity: Int
        get() = int("sidebar_opacity", 96).coerceIn(40, 100)
        set(v) = putInt("sidebar_opacity", v)

    var sidebarShowFavorites: Boolean
        get() = bool("sb_fav", true)
        set(v) = putBool("sb_fav", v)

    var sidebarShowRecent: Boolean
        get() = bool("sb_recent", true)
        set(v) = putBool("sb_recent", v)

    var sidebarShowTools: Boolean
        get() = bool("sb_tools", true)
        set(v) = putBool("sb_tools", v)

    var sidebarShowQuickSettings: Boolean
        get() = bool("sb_quick", true)
        set(v) = putBool("sb_quick", v)

    // ---- Favorites and recent apps (stored as ordered lists of app keys) ----
    var favorites: List<String>
        get() = readList("favorites")
        set(v) = writeList("favorites", v)

    var recents: List<String>
        get() = readList("recents")
        set(v) = writeList("recents", v)

    fun isFavorite(key: String) = favorites.contains(key)

    fun toggleFavorite(key: String): Boolean {
        val list = favorites.toMutableList()
        val nowFavorite = if (list.remove(key)) false else { list.add(key); true }
        favorites = list
        return nowFavorite
    }

    fun moveFavorite(key: String, delta: Int) {
        val list = favorites.toMutableList()
        val index = list.indexOf(key)
        val target = index + delta
        if (index < 0 || target !in list.indices) return
        list.removeAt(index)
        list.add(target, key)
        favorites = list
    }

    fun addRecent(key: String) {
        val list = recents.toMutableList()
        list.remove(key)
        list.add(0, key)
        recents = list.take(MAX_RECENTS)
    }

    fun clearRecents() {
        recents = emptyList()
    }

    // ---- Quick notes ----
    var notes: String
        get() = prefs.getString("notes", "") ?: ""
        set(v) = prefs.edit().putString("notes", v).apply()

    private fun readList(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split(SEPARATOR).filter { it.isNotBlank() }

    private fun writeList(key: String, list: List<String>) =
        prefs.edit().putString(key, list.joinToString(SEPARATOR)).apply()

    companion object {
        private const val SEPARATOR = "\n"
        private const val MAX_RECENTS = 15
    }
}
