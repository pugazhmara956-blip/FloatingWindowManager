package com.allapps.floatingwindow.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.IBinder
import android.widget.PopupMenu
import androidx.core.app.ServiceCompat
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.WindowManagerHelper
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.overlay.CalculatorPanel
import com.allapps.floatingwindow.overlay.FloatingBubble
import com.allapps.floatingwindow.overlay.FloatingWindow
import com.allapps.floatingwindow.overlay.LauncherPanel
import com.allapps.floatingwindow.overlay.NotesPanel
import com.allapps.floatingwindow.overlay.OverlayTheme

/**
 * Shows the floating button and manages floating windows (launcher, calculator, notes):
 * opening, focusing, minimizing into bubbles, restoring and closing.
 * It does no background work: it only reacts to taps.
 */
class FloatingWindowService : Service(), FloatingWindow.Listener {

    companion object {
        private const val NOTIFICATION_ID = 2001
        const val ACTION_START = "com.allapps.floatingwindow.window.START"
        const val ACTION_SHOW_LAUNCHER = "com.allapps.floatingwindow.window.LAUNCHER"
        const val ACTION_OPEN_CALCULATOR = "com.allapps.floatingwindow.window.CALCULATOR"
        const val ACTION_OPEN_NOTES = "com.allapps.floatingwindow.window.NOTES"
        const val ACTION_OPEN_TEST = "com.allapps.floatingwindow.window.TEST"
        const val ACTION_REFRESH = "com.allapps.floatingwindow.window.REFRESH"
        const val ACTION_STOP = "com.allapps.floatingwindow.window.STOP"

        @Volatile
        var isRunning = false
            private set

        fun send(context: Context, action: String): Boolean =
            ServiceNotifications.startService(context, FloatingWindowService::class.java, action)

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingWindowService::class.java))
        }
    }

    private lateinit var settings: SettingsRepository
    private lateinit var theme: OverlayTheme
    private var mainBubble: FloatingBubble? = null
    private val windows = ArrayList<FloatingWindow>()
    private val minimized = HashMap<FloatingWindow, FloatingBubble>()
    private val panels = HashMap<FloatingWindow, Any>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        theme = OverlayTheme.from(this, settings)
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceNotifications.goForeground(
            this, NOTIFICATION_ID, R.string.notif_window_title, R.string.notif_window_text, ACTION_STOP
        )
        when (intent?.action) {
            ACTION_STOP -> {
                settings.bubbleEnabled = false
                shutDown()
                return START_NOT_STICKY
            }
            ACTION_SHOW_LAUNCHER -> openOrFocus(FloatingWindow.Kind.LAUNCHER)
            ACTION_OPEN_CALCULATOR -> openOrFocus(FloatingWindow.Kind.CALCULATOR)
            ACTION_OPEN_NOTES -> openOrFocus(FloatingWindow.Kind.NOTES)
            ACTION_OPEN_TEST -> openOrFocus(FloatingWindow.Kind.NOTES, useDefaultRect = true)
            ACTION_REFRESH -> refreshAppearance()
        }
        updateMainBubble()
        stopIfIdle()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Screen rotated or resized: keep every window reachable.
        windows.forEach { it.keepOnScreen() }
    }

    override fun onDestroy() {
        windows.forEach { (panels[it] as? NotesPanel)?.save() }
        windows.forEach { it.destroy() }
        windows.clear()
        minimized.values.forEach { it.remove() }
        minimized.clear()
        mainBubble?.remove()
        mainBubble = null
        isRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ windows

    private fun openOrFocus(kind: FloatingWindow.Kind, useDefaultRect: Boolean = false) {
        val existing = windows.firstOrNull { it.kind == kind }
        if (existing != null) {
            minimized.remove(existing)?.remove()
            if (existing.isShowing) existing.bringToFront() else existing.restore()
            moveToTop(existing)
            (panels[existing] as? LauncherPanel)?.reload()
            return
        }
        val window = FloatingWindow(this, kind, settings, theme, this)
        val content = when (kind) {
            FloatingWindow.Kind.LAUNCHER -> LauncherPanel(window.context, theme, settings, window) {
                onWindowMinimized(window)
            }.also { window.setContent(it.view) }
            FloatingWindow.Kind.CALCULATOR -> CalculatorPanel(window.context, theme).also { window.setContent(it.view) }
            FloatingWindow.Kind.NOTES -> NotesPanel(window.context, theme, settings, window).also { window.setContent(it.view) }
        }
        panels[window] = content
        val rect = WindowManagerHelper.defaultWindowRect(this, settings)
        if (!useDefaultRect) {
            // Cascade new windows so they do not cover each other exactly.
            val offset = WindowManagerHelper.dp(this, 28f) * windows.size
            rect.offset(offset, offset)
        }
        windows.add(window)
        window.show(rect)
    }

    private fun moveToTop(window: FloatingWindow) {
        windows.remove(window)
        windows.add(window)
    }

    override fun onWindowTouched(window: FloatingWindow) {
        val top = windows.lastOrNull { it.isShowing }
        if (top != window && window.isShowing) {
            window.bringToFront()
            moveToTop(window)
        }
    }

    override fun onWindowMinimized(window: FloatingWindow) {
        (panels[window] as? NotesPanel)?.save()
        window.hide()
        if (minimized.containsKey(window)) return
        val bubble = FloatingBubble(
            this, theme, (settings.bubbleSizeDp * 0.8f).toInt(), window.kind.iconRes,
            getString(window.kind.titleRes), settings.animationSpeed,
            onTap = { restore(window) }
        )
        minimized[window] = bubble
        val screen = WindowManagerHelper.screenSize(this)
        val size = WindowManagerHelper.dp(this, settings.bubbleSizeDp * 0.8f)
        val gap = WindowManagerHelper.dp(this, 10f)
        val index = minimized.size
        bubble.show(screen.x - size - gap, screen.y / 3 + index * (size + gap))
    }

    private fun restore(window: FloatingWindow) {
        minimized.remove(window)?.remove()
        window.restore()
        moveToTop(window)
        (panels[window] as? LauncherPanel)?.reload()
    }

    override fun onWindowClosed(window: FloatingWindow) {
        (panels[window] as? NotesPanel)?.save()
        windows.remove(window)
        panels.remove(window)
        minimized.remove(window)?.remove()
        stopIfIdle()
    }

    // ------------------------------------------------------------------ floating button

    private fun updateMainBubble() {
        if (!settings.bubbleEnabled) {
            mainBubble?.remove()
            mainBubble = null
            return
        }
        if (mainBubble != null) return
        val bubble = FloatingBubble(
            this, theme, settings.bubbleSizeDp, R.drawable.ic_windows,
            getString(R.string.cd_bubble), settings.animationSpeed,
            onTap = { toggleLauncher() },
            onLongPress = { showBubbleMenu() }
        )
        val screen = WindowManagerHelper.screenSize(this)
        val size = WindowManagerHelper.dp(this, settings.bubbleSizeDp.toFloat())
        bubble.show(screen.x - size - WindowManagerHelper.dp(this, 6f), (screen.y * 0.55f).toInt())
        mainBubble = bubble
    }

    private fun toggleLauncher() {
        val launcher = windows.firstOrNull { it.kind == FloatingWindow.Kind.LAUNCHER }
        if (launcher != null && launcher.isShowing) onWindowMinimized(launcher)
        else openOrFocus(FloatingWindow.Kind.LAUNCHER)
    }

    private fun showBubbleMenu() {
        val bubble = mainBubble ?: return
        val menu = PopupMenu(theme.themedContext(this), bubble.view)
        menu.menu.add(0, 1, 0, R.string.bubble_menu_launcher)
        menu.menu.add(0, 2, 1, R.string.bubble_menu_calculator)
        menu.menu.add(0, 3, 2, R.string.bubble_menu_notes)
        menu.menu.add(0, 4, 3, R.string.bubble_menu_sidebar)
        menu.menu.add(0, 5, 4, R.string.bubble_menu_hide)
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openOrFocus(FloatingWindow.Kind.LAUNCHER)
                2 -> openOrFocus(FloatingWindow.Kind.CALCULATOR)
                3 -> openOrFocus(FloatingWindow.Kind.NOTES)
                4 -> FloatingSidebarService.send(this, FloatingSidebarService.ACTION_OPEN)
                5 -> {
                    settings.bubbleEnabled = false
                    updateMainBubble()
                    stopIfIdle()
                }
            }
            true
        }
        try {
            menu.show()
        } catch (e: Exception) {
            // Pop-up menus over overlays are blocked on some systems; open the launcher instead.
            openOrFocus(FloatingWindow.Kind.LAUNCHER)
        }
    }

    private fun refreshAppearance() {
        val newTheme = OverlayTheme.from(this, settings)
        if (newTheme.dark != theme.dark) {
            // Rebuild everything with the new colors.
            theme = newTheme
            windows.forEach { (panels[it] as? NotesPanel)?.save() }
            windows.forEach { it.destroy() }
            windows.clear()
            panels.clear()
            minimized.values.forEach { it.remove() }
            minimized.clear()
        } else {
            windows.forEach { it.applyAppearance() }
        }
        mainBubble?.remove()
        mainBubble = null
    }

    private fun stopIfIdle() {
        if (!settings.bubbleEnabled && windows.isEmpty()) shutDown()
    }

    private fun shutDown() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
