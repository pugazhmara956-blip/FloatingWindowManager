package com.allapps.floatingwindow.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ServiceCompat
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.AppLauncher
import com.allapps.floatingwindow.core.WindowManagerHelper
import com.allapps.floatingwindow.data.ApplicationRepository
import com.allapps.floatingwindow.data.AppInfo
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.data.SidebarSide
import com.allapps.floatingwindow.overlay.OverlayTheme
import com.allapps.floatingwindow.overlay.WindowFrame
import com.allapps.floatingwindow.ui.SidebarSettingsActivity
import kotlin.math.abs
import kotlin.math.min

/**
 * Shows a thin handle on the screen edge. Swiping inward (or tapping) opens the sidebar with
 * favorite apps, recent apps, tools and quick settings shortcuts.
 */
class FloatingSidebarService : Service() {

    companion object {
        private const val TAG = "SidebarService"
        private const val NOTIFICATION_ID = 3001
        private const val COLUMNS = 4
        const val ACTION_START = "com.allapps.floatingwindow.sidebar.START"
        const val ACTION_OPEN = "com.allapps.floatingwindow.sidebar.OPEN"
        const val ACTION_REFRESH = "com.allapps.floatingwindow.sidebar.REFRESH"
        const val ACTION_STOP = "com.allapps.floatingwindow.sidebar.STOP"

        @Volatile
        var isRunning = false
            private set

        fun send(context: Context, action: String): Boolean =
            ServiceNotifications.startService(context, FloatingSidebarService::class.java, action)

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingSidebarService::class.java))
        }
    }

    private lateinit var settings: SettingsRepository
    private lateinit var theme: OverlayTheme
    private lateinit var ctx: Context
    private lateinit var wm: WindowManager
    private var handleView: View? = null
    private var panelView: WindowFrame? = null
    private var panelCard: View? = null
    private var panelWidth = 0
    private var torchCameraId: String? = null
    private var torchOn = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) torchOn = enabled
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        theme = OverlayTheme.from(this, settings)
        ctx = theme.themedContext(this)
        wm = WindowManagerHelper.windowManager(this)
        setUpTorch()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceNotifications.goForeground(
            this, NOTIFICATION_ID, R.string.notif_sidebar_title, R.string.notif_sidebar_text, ACTION_STOP
        )
        when (intent?.action) {
            ACTION_STOP -> {
                settings.sidebarEnabled = false
                shutDown()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                closePanel(animate = false)
                removeHandle()
                theme = OverlayTheme.from(this, settings)
                ctx = theme.themedContext(this)
            }
            ACTION_OPEN -> {
                updateHandle()
                openPanel()
                return START_STICKY
            }
        }
        updateHandle()
        if (!settings.sidebarEnabled && panelView == null) {
            shutDown()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        closePanel(animate = false)
        removeHandle()
        try {
            getSystemService(CameraManager::class.java)?.unregisterTorchCallback(torchCallback)
        } catch (e: Exception) {
            Log.w(TAG, "Torch callback was not registered", e)
        }
        isRunning = false
        super.onDestroy()
    }

    private fun shutDown() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ edge handle

    @SuppressLint("ClickableViewAccessibility")
    private fun updateHandle() {
        if (!settings.sidebarEnabled) {
            removeHandle()
            return
        }
        if (handleView != null) return
        val left = settings.sidebarSide == SidebarSide.LEFT
        val touchWidth = dp(22f)
        val height = dp(110f)
        val frame = FrameLayout(ctx)
        val pill = View(ctx).apply {
            background = theme.rounded(theme.accent, dp(4f).toFloat())
            alpha = 0.85f
        }
        frame.addView(pill, FrameLayout.LayoutParams(dp(6f), dp(84f), Gravity.CENTER_VERTICAL or if (left) Gravity.START else Gravity.END).apply {
            if (left) marginStart = dp(2f) else marginEnd = dp(2f)
        })
        frame.contentDescription = getString(R.string.cd_sidebar_handle)
        frame.setOnClickListener { openPanel() }

        val params = WindowManagerHelper.overlayParams(touchWidth, height).apply {
            flags = flags and WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH.inv()
            gravity = Gravity.TOP or if (left) Gravity.START else Gravity.END
            x = 0
            y = (WindowManagerHelper.screenSize(this@FloatingSidebarService).y * settings.sidebarOffsetPct / 100f).toInt()
        }

        var downX = 0f
        var downY = 0f
        var opened = false
        frame.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    opened = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val inward = if (left) dx else -dx
                    if (!opened && inward > dp(16f)) {
                        opened = true
                        openPanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!opened && abs(e.rawX - downX) < dp(10f) && abs(e.rawY - downY) < dp(10f)) openPanel()
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(frame, params)
            handleView = frame
        } catch (e: Exception) {
            Log.w(TAG, "Could not add the sidebar handle", e)
        }
    }

    private fun removeHandle() {
        val v = handleView ?: return
        handleView = null
        try {
            wm.removeViewImmediate(v)
        } catch (e: Exception) {
            Log.w(TAG, "Handle already removed", e)
        }
    }

    // ------------------------------------------------------------------ sidebar panel

    private fun openPanel() {
        if (panelView != null) return
        val screen = WindowManagerHelper.screenSize(this)
        val left = settings.sidebarSide == SidebarSide.LEFT
        val top = WindowManagerHelper.statusBarHeight(this)
        panelWidth = min(dp(300f), (screen.x * 0.86f).toInt())
        val panelHeight = screen.y - top - dp(32f)

        val root = WindowFrame(ctx)
        root.onOutsideTouch = { closePanel() }
        root.onBackPressed = { closePanel() }

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = theme.rounded(theme.windowBg, dp(24f).toFloat(), dp(1f))
            clipToOutline = true
        }
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Header
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(10f), dp(6f), dp(4f))
        }
        header.addView(TextView(ctx).apply {
            text = getString(R.string.sidebar_title)
            setTextColor(theme.text)
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(ImageButton(ctx).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(theme.text)
            background = null
            contentDescription = getString(R.string.cd_close)
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(dp(44f), dp(44f)))
        card.addView(header)

        val scroll = ScrollView(ctx)
        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(12f), dp(16f))
        }
        scroll.addView(column)
        card.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val favoritesGrid = grid()
        val recentGrid = grid()
        if (settings.sidebarShowFavorites) {
            column.addView(sectionLabel(R.string.sidebar_favorites))
            column.addView(favoritesGrid)
        }
        if (settings.sidebarShowRecent) {
            column.addView(sectionLabel(R.string.sidebar_recent))
            column.addView(recentGrid)
        }
        if (settings.sidebarShowTools) {
            column.addView(sectionLabel(R.string.sidebar_tools))
            val tools = grid()
            tools.addView(iconTile(R.drawable.ic_apps, getString(R.string.sidebar_all_apps)) {
                closePanel()
                FloatingWindowService.send(this, FloatingWindowService.ACTION_SHOW_LAUNCHER)
            })
            tools.addView(iconTile(R.drawable.ic_calculator, getString(R.string.window_calculator)) {
                closePanel()
                FloatingWindowService.send(this, FloatingWindowService.ACTION_OPEN_CALCULATOR)
            })
            tools.addView(iconTile(R.drawable.ic_notes, getString(R.string.window_notes)) {
                closePanel()
                FloatingWindowService.send(this, FloatingWindowService.ACTION_OPEN_NOTES)
            })
            column.addView(tools)
        }
        if (settings.sidebarShowQuickSettings) {
            column.addView(sectionLabel(R.string.sidebar_quick_settings))
            column.addView(quickSettingsGrid())
        }
        column.addView(TextView(ctx).apply {
            text = getString(R.string.sidebar_settings)
            setTextColor(theme.accent)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(18f), 0, dp(8f))
            isClickable = true
            setOnClickListener {
                closePanel()
                AppLauncher.start(this@FloatingSidebarService, Intent(this@FloatingSidebarService, SidebarSettingsActivity::class.java), null)
            }
        })

        val params = WindowManagerHelper.overlayParams(panelWidth, panelHeight).apply {
            gravity = Gravity.TOP or if (left) Gravity.START else Gravity.END
            x = dp(8f)
            y = top + dp(16f)
            alpha = settings.sidebarOpacity / 100f
        }
        try {
            wm.addView(root, params)
            panelView = root
            panelCard = card
            card.translationX = if (left) -panelWidth.toFloat() else panelWidth.toFloat()
            card.animate().translationX(0f).setDuration(animDuration(220)).start()
        } catch (e: Exception) {
            Log.w(TAG, "Could not open the sidebar", e)
            return
        }

        ApplicationRepository.load(this) { apps ->
            if (panelView !== root) return@load
            fillApps(favoritesGrid, settings.favorites, apps, showEmptyHint = true)
            fillApps(recentGrid, settings.recents.take(8), apps, showEmptyHint = false)
        }
    }

    private fun closePanel(animate: Boolean = true) {
        val root = panelView ?: return
        val card = panelCard
        panelView = null
        panelCard = null
        val remove = {
            try {
                wm.removeViewImmediate(root)
            } catch (e: Exception) {
                Log.w(TAG, "Sidebar already removed", e)
            }
            if (!settings.sidebarEnabled) shutDown()
        }
        if (animate && card != null) {
            val left = settings.sidebarSide == SidebarSide.LEFT
            card.animate()
                .translationX(if (left) -panelWidth.toFloat() else panelWidth.toFloat())
                .setDuration(animDuration(180))
                .withEndAction { remove() }
                .start()
        } else {
            remove()
        }
    }

    private fun fillApps(grid: GridLayout, keys: List<String>, apps: List<AppInfo>, showEmptyHint: Boolean) {
        grid.removeAllViews()
        val items = keys.mapNotNull { key -> apps.firstOrNull { it.key == key } }
        if (items.isEmpty()) {
            if (showEmptyHint) {
                grid.addView(TextView(ctx).apply {
                    text = getString(R.string.sidebar_no_favorites)
                    setTextColor(theme.textSecondary)
                    textSize = 13f
                    setPadding(dp(6f), dp(4f), dp(6f), dp(4f))
                }, GridLayout.LayoutParams(GridLayout.spec(0), GridLayout.spec(0, COLUMNS)).apply {
                    width = panelWidth - dp(24f)
                })
            }
            return
        }
        items.forEach { app ->
            grid.addView(appTile(app.icon, app.label) {
                closePanel()
                AppLauncher.launch(this, app, AppLauncher.defaultMode(this, settings))
            })
        }
    }

    private fun quickSettingsGrid(): GridLayout {
        val g = grid()
        val q = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        g.addView(iconTile(R.drawable.ic_wifi, getString(R.string.qs_wifi)) {
            openSetting(if (q) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
        })
        g.addView(iconTile(R.drawable.ic_internet, getString(R.string.qs_internet)) {
            openSetting(if (q) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS)
        })
        g.addView(iconTile(R.drawable.ic_bluetooth, getString(R.string.qs_bluetooth)) {
            openSetting(Settings.ACTION_BLUETOOTH_SETTINGS)
        })
        g.addView(iconTile(R.drawable.ic_volume, getString(R.string.qs_volume)) {
            openSetting(if (q) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS)
        })
        if (torchCameraId != null) {
            g.addView(iconTile(R.drawable.ic_flashlight, getString(R.string.qs_flashlight)) { toggleTorch() })
        }
        g.addView(iconTile(R.drawable.ic_display, getString(R.string.qs_display)) {
            openSetting(Settings.ACTION_DISPLAY_SETTINGS)
        })
        g.addView(iconTile(R.drawable.ic_settings, getString(R.string.qs_settings)) {
            openSetting(Settings.ACTION_SETTINGS)
        })
        return g
    }

    private fun openSetting(action: String) {
        closePanel()
        AppLauncher.start(this, Intent(action), null)
    }

    // ------------------------------------------------------------------ flashlight

    private fun setUpTorch() {
        val cm = getSystemService(CameraManager::class.java) ?: return
        try {
            torchCameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (torchCameraId != null) cm.registerTorchCallback(torchCallback, mainHandler)
        } catch (e: Exception) {
            Log.w(TAG, "Flashlight not available", e)
            torchCameraId = null
        }
    }

    private fun toggleTorch() {
        val id = torchCameraId ?: return
        try {
            getSystemService(CameraManager::class.java)?.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.flashlight_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ view helpers

    private fun grid() = GridLayout(ctx).apply {
        columnCount = COLUMNS
        setPadding(0, dp(4f), 0, dp(4f))
    }

    private fun tileWidth() = (panelWidth - dp(24f)) / COLUMNS

    private fun sectionLabel(textRes: Int) = TextView(ctx).apply {
        text = getString(textRes).uppercase()
        setTextColor(theme.accent)
        textSize = 12f
        letterSpacing = 0.08f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(6f), dp(14f), dp(6f), dp(2f))
    }

    private fun appTile(icon: Drawable, label: String, onClick: () -> Unit): View =
        tile(label, onClick) { iv ->
            iv.setImageDrawable(icon)
        }

    private fun iconTile(iconRes: Int, label: String, onClick: () -> Unit): View =
        tile(label, onClick) { iv ->
            iv.setImageResource(iconRes)
            iv.setColorFilter(theme.accent)
            iv.background = theme.rounded(theme.keyBg, dp(20f).toFloat())
            val p = dp(9f)
            iv.setPadding(p, p, p, p)
        }

    private fun tile(label: String, onClick: () -> Unit, setUpIcon: (ImageView) -> Unit): View {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2f), dp(6f), dp(2f), dp(6f))
            isClickable = true
            isFocusable = true
            contentDescription = label
            setOnClickListener { onClick() }
        }
        val iv = ImageView(ctx)
        setUpIcon(iv)
        box.addView(iv, LinearLayout.LayoutParams(dp(42f), dp(42f)))
        box.addView(TextView(ctx).apply {
            text = label
            setTextColor(theme.text)
            textSize = 10.5f
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4f)
        })
        box.layoutParams = GridLayout.LayoutParams().apply { width = tileWidth() }
        return box
    }

    private fun animDuration(ms: Long) = (ms / settings.animationSpeed).toLong()

    private fun dp(v: Float) = WindowManagerHelper.dp(this, v)
}
