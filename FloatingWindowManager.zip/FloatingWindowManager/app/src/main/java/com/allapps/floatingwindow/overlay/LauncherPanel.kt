package com.allapps.floatingwindow.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.AppLauncher
import com.allapps.floatingwindow.core.WindowManagerHelper
import com.allapps.floatingwindow.data.AppInfo
import com.allapps.floatingwindow.data.ApplicationRepository
import com.allapps.floatingwindow.data.LaunchMode
import com.allapps.floatingwindow.data.SettingsRepository

/** The floating launcher: search, favorites, recent apps and all apps in a grid. */
class LauncherPanel(
    private val context: Context,
    private val theme: OverlayTheme,
    private val settings: SettingsRepository,
    private val window: FloatingWindow,
    private val onAppLaunched: () -> Unit
) {
    private enum class Tab { FAVORITES, RECENT, ALL }

    val view = LinearLayout(context)
    private val search = EditText(context)
    private val tabViews = HashMap<Tab, TextView>()
    private val list = RecyclerView(context)
    private val empty = TextView(context)
    private val adapter = GridAdapter()
    private var allApps: List<AppInfo> = emptyList()
    private var tab = if (settings.favorites.isEmpty()) Tab.ALL else Tab.FAVORITES

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setPadding(dp(10f), dp(8f), dp(10f), 0)

        search.apply {
            hint = context.getString(R.string.search_apps)
            setHintTextColor(theme.textSecondary)
            setTextColor(theme.text)
            textSize = 15f
            isSingleLine = true
            background = theme.rounded(theme.fieldBg, dp(14f).toFloat(), dp(1f))
            setPadding(dp(14f), 0, dp(14f), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    if (!s.isNullOrBlank()) selectTab(Tab.ALL, refresh = false)
                    refresh()
                }
            })
        }
        enableKeyboardOnTouch(search)
        view.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44f)))

        val tabs = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8f), 0, dp(4f))
        }
        addTab(tabs, Tab.FAVORITES, R.string.tab_favorites)
        addTab(tabs, Tab.RECENT, R.string.tab_recent)
        addTab(tabs, Tab.ALL, R.string.tab_all)
        view.addView(tabs)

        list.layoutManager = GridLayoutManager(context, 4)
        list.adapter = adapter
        list.clipToPadding = false
        list.setPadding(0, 0, 0, dp(28f))
        view.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        empty.apply {
            setTextColor(theme.textSecondary)
            gravity = Gravity.CENTER
            setPadding(dp(16f), dp(24f), dp(16f), dp(24f))
            text = context.getString(R.string.loading_apps)
        }
        view.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        selectTab(tab, refresh = false)
        reload()
    }

    /** Reloads favorites and recent apps (for example, after they changed in the app). */
    fun reload() {
        ApplicationRepository.load(context) { apps ->
            allApps = apps
            refresh()
        }
    }

    private fun addTab(parent: LinearLayout, t: Tab, labelRes: Int) {
        val tv = TextView(context).apply {
            text = context.getString(labelRes)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(14f), dp(7f), dp(14f), dp(7f))
            setOnClickListener {
                search.setText("")
                selectTab(t)
            }
        }
        parent.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(6f)
        })
        tabViews[t] = tv
    }

    private fun selectTab(t: Tab, refresh: Boolean = true) {
        tab = t
        tabViews.forEach { (key, tv) ->
            val selected = key == t
            tv.background = theme.rounded(if (selected) theme.accent else theme.keyBg, dp(16f).toFloat())
            tv.setTextColor(if (selected) theme.onAccent else theme.text)
        }
        if (refresh) refresh()
    }

    private fun refresh() {
        val query = search.text?.toString()?.trim().orEmpty()
        val items: List<AppInfo> = when {
            query.isNotEmpty() -> allApps.filter { it.label.contains(query, ignoreCase = true) }
            tab == Tab.FAVORITES -> settings.favorites.mapNotNull { key -> allApps.firstOrNull { it.key == key } }
            tab == Tab.RECENT -> settings.recents.mapNotNull { key -> allApps.firstOrNull { it.key == key } }
            else -> allApps
        }
        adapter.submit(items)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        empty.text = when {
            allApps.isEmpty() -> context.getString(R.string.loading_apps)
            query.isNotEmpty() -> context.getString(R.string.empty_search)
            tab == Tab.FAVORITES -> context.getString(R.string.empty_favorites)
            tab == Tab.RECENT -> context.getString(R.string.empty_recent)
            else -> context.getString(R.string.empty_search)
        }
    }

    private fun launch(app: AppInfo, mode: LaunchMode) {
        window.setKeyboardEnabled(false)
        hideKeyboard()
        val result = AppLauncher.launch(context, app, mode)
        if (result != AppLauncher.Result.FAILED) onAppLaunched()
    }

    private fun showOptions(app: AppInfo, anchor: View) {
        val menu = PopupMenu(context, anchor)
        val favorite = settings.isFavorite(app.key)
        menu.menu.add(0, 1, 0, R.string.action_open_full)
        menu.menu.add(0, 2, 1, R.string.action_open_window)
        menu.menu.add(0, 3, 2, R.string.action_open_side)
        menu.menu.add(0, 4, 3, if (favorite) R.string.action_remove_favorite else R.string.action_add_favorite)
        menu.menu.add(0, 5, 4, R.string.action_app_info)
        menu.menu.add(0, 6, 5, R.string.action_why)
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> launch(app, LaunchMode.FULL_SCREEN)
                2 -> launch(app, LaunchMode.FLOATING_WINDOW)
                3 -> launch(app, LaunchMode.SIDE_BY_SIDE)
                4 -> {
                    settings.toggleFavorite(app.key)
                    refresh()
                }
                5 -> {
                    AppLauncher.openAppInfo(context, app.packageName)
                    onAppLaunched()
                }
                6 -> Toast.makeText(context, AppLauncher.explainSupport(context, app), Toast.LENGTH_LONG).show()
            }
            true
        }
        try {
            menu.show()
        } catch (e: Exception) {
            // Some systems do not allow pop-up menus over overlay windows. Fall back to a normal launch.
            launch(app, AppLauncher.defaultMode(context, settings))
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun enableKeyboardOnTouch(field: EditText) {
        field.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                window.setKeyboardEnabled(true)
                v.post {
                    v.requestFocus()
                    context.getSystemService(InputMethodManager::class.java)
                        ?.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
                }
            }
            false
        }
    }

    private fun hideKeyboard() {
        context.getSystemService(InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dp(v: Float) = WindowManagerHelper.dp(context, v)

    private inner class GridAdapter : RecyclerView.Adapter<GridAdapter.Holder>() {
        private var items: List<AppInfo> = emptyList()

        @SuppressLint("NotifyDataSetChanged")
        fun submit(newItems: List<AppInfo>) {
            items = newItems
            notifyDataSetChanged()
        }

        inner class Holder(val root: LinearLayout, val icon: ImageView, val label: TextView) :
            RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val root = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4f), dp(8f), dp(4f), dp(8f))
                isClickable = true
                isFocusable = true
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val icon = ImageView(context)
            root.addView(icon, LinearLayout.LayoutParams(dp(44f), dp(44f)))
            val label = TextView(context).apply {
                setTextColor(theme.text)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            root.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4f)
            })
            return Holder(root, icon, label)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val app = items[position]
            holder.icon.setImageDrawable(app.icon)
            holder.label.text = app.label
            holder.root.contentDescription = app.label
            holder.root.setOnClickListener { launch(app, AppLauncher.defaultMode(context, settings)) }
            holder.root.setOnLongClickListener {
                showOptions(app, holder.root)
                true
            }
        }

        override fun getItemCount() = items.size
    }
}
