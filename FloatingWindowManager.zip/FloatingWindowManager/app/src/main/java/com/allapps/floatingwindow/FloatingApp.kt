package com.allapps.floatingwindow

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.allapps.floatingwindow.data.SettingsRepository
import com.allapps.floatingwindow.data.ThemeMode

/** Applies the saved theme (dark, light or system) before any screen opens. */
class FloatingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        applyTheme(SettingsRepository(this).themeMode)
    }

    companion object {
        fun applyTheme(mode: ThemeMode) {
            AppCompatDelegate.setDefaultNightMode(
                when (mode) {
                    ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
                    ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                    ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
