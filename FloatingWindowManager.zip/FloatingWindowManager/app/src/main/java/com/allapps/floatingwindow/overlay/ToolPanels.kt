package com.allapps.floatingwindow.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.WindowManagerHelper
import com.allapps.floatingwindow.data.SettingsRepository
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs
import kotlin.math.floor

/** Evaluates calculator expressions with +, -, x, / and % using normal operator precedence. */
object ExpressionEvaluator {

    fun evaluate(expression: String): Double? {
        val s = expression.replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "")
        if (s.isEmpty()) return null
        val parser = Parser(s)
        val value = parser.expression() ?: return null
        return if (parser.atEnd() && value.isFinite()) value else null
    }

    fun format(value: Double): String =
        if (value == floor(value) && abs(value) < 1e15) {
            value.toLong().toString()
        } else {
            BigDecimal(value).round(MathContext(12)).stripTrailingZeros().toPlainString()
        }

    private class Parser(private val s: String) {
        private var pos = 0

        fun atEnd() = pos >= s.length

        fun expression(): Double? {
            var left = term() ?: return null
            while (!atEnd() && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val right = term() ?: return null
                left = if (op == '+') left + right else left - right
            }
            return left
        }

        private fun term(): Double? {
            var left = factor() ?: return null
            while (!atEnd() && (s[pos] == '*' || s[pos] == '/')) {
                val op = s[pos++]
                val right = factor() ?: return null
                if (op == '/' && right == 0.0) return null
                left = if (op == '*') left * right else left / right
            }
            return left
        }

        private fun factor(): Double? {
            if (!atEnd() && s[pos] == '-') {
                pos++
                return factor()?.let { -it }
            }
            val start = pos
            while (!atEnd() && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) return null
            var value = s.substring(start, pos).toDoubleOrNull() ?: return null
            while (!atEnd() && s[pos] == '%') {
                value /= 100.0
                pos++
            }
            return value
        }
    }
}

/** A floating calculator. */
class CalculatorPanel(private val context: Context, private val theme: OverlayTheme) {

    val view = LinearLayout(context)
    private val expressionView = TextView(context)
    private val resultView = TextView(context)
    private var expression = ""

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setPadding(dp(12f), dp(8f), dp(12f), dp(12f))

        expressionView.apply {
            setTextColor(theme.text)
            textSize = 26f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 2
        }
        resultView.apply {
            setTextColor(theme.textSecondary)
            textSize = 16f
            gravity = Gravity.END
        }
        view.addView(expressionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        view.addView(resultView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val keys = listOf(
            "C", "⌫", "%", "÷",
            "7", "8", "9", "×",
            "4", "5", "6", "−",
            "1", "2", "3", "+",
            "00", "0", ".", "="
        )
        val grid = GridLayout(context).apply {
            columnCount = 4
            rowCount = 5
        }
        keys.forEachIndexed { index, key ->
            val isOperator = key in setOf("÷", "×", "−", "+", "=")
            val button = TextView(context).apply {
                text = key
                textSize = 20f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (key == "=") theme.onAccent else if (isOperator) theme.accent else theme.text)
                background = theme.rounded(if (key == "=") theme.accent else theme.keyBg, dp(14f).toFloat())
                isClickable = true
                isFocusable = true
                contentDescription = describe(key)
                setOnClickListener { press(key) }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(index / 4, 1f),
                GridLayout.spec(index % 4, 1f)
            ).apply {
                width = 0
                height = 0
                setMargins(dp(3f), dp(3f), dp(3f), dp(3f))
            }
            grid.addView(button, params)
        }
        view.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f))
        update()
    }

    private fun press(key: String) {
        val operators = "+−×÷"
        when (key) {
            "C" -> expression = ""
            "⌫" -> expression = expression.dropLast(1)
            "=" -> {
                val value = ExpressionEvaluator.evaluate(expression)
                expression = value?.let { ExpressionEvaluator.format(it) } ?: expression
                if (value == null && expression.isNotEmpty()) {
                    resultView.text = context.getString(R.string.calc_error)
                    expressionView.text = expression
                    return
                }
            }
            "+", "−", "×", "÷" -> {
                expression = when {
                    expression.isEmpty() -> if (key == "−") key else ""
                    expression.last() in operators -> expression.dropLast(1) + key
                    else -> expression + key
                }
            }
            "." -> {
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "%" -> if (expression.isNotEmpty() && expression.last().isDigit()) expression += "%"
            else -> expression += key
        }
        update()
    }

    private fun update() {
        expressionView.text = expression.ifEmpty { "0" }
        val preview = ExpressionEvaluator.evaluate(expression)
        resultView.text = if (preview != null && expression.any { it in "+−×÷%" }) "= " + ExpressionEvaluator.format(preview) else ""
    }

    private fun describe(key: String) = when (key) {
        "⌫" -> "Delete"
        "÷" -> "Divide"
        "×" -> "Multiply"
        "−" -> "Minus"
        "+" -> "Plus"
        "=" -> "Equals"
        "%" -> "Percent"
        "C" -> "Clear"
        "." -> "Decimal point"
        else -> key
    }

    private fun dp(v: Float) = WindowManagerHelper.dp(context, v)
}

/** Quick notes that are saved automatically on the phone. */
class NotesPanel(
    private val context: Context,
    private val theme: OverlayTheme,
    private val settings: SettingsRepository,
    private val window: FloatingWindow
) {
    val view = LinearLayout(context)
    private val editor = EditText(context)
    private val handler = Handler(Looper.getMainLooper())
    private val saveRunnable = Runnable { settings.notes = editor.text?.toString().orEmpty() }
    private var clearArmed = false

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setPadding(dp(10f), dp(8f), dp(10f), dp(10f))

        editor.apply {
            setText(settings.notes)
            hint = context.getString(R.string.notes_hint)
            setHintTextColor(theme.textSecondary)
            setTextColor(theme.text)
            textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            background = theme.rounded(theme.fieldBg, dp(14f).toFloat(), dp(1f))
            setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    handler.removeCallbacks(saveRunnable)
                    handler.postDelayed(saveRunnable, 500)
                }
            })
        }
        enableKeyboardOnTouch(editor)
        view.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8f), 0, 0)
        }
        row.addView(button(R.string.notes_copy) { copy() }, LinearLayout.LayoutParams(0, dp(42f), 1f))
        row.addView(button(R.string.notes_clear) { clear() }, LinearLayout.LayoutParams(0, dp(42f), 1f).apply {
            marginStart = dp(8f)
        })
        view.addView(row)
    }

    /** Saves any pending changes immediately. */
    fun save() {
        handler.removeCallbacks(saveRunnable)
        saveRunnable.run()
    }

    private fun copy() {
        val clipboard = context.getSystemService(ClipboardManager::class.java) ?: return
        clipboard.setPrimaryClip(ClipData.newPlainText(context.getString(R.string.window_notes), editor.text))
        Toast.makeText(context, R.string.notes_copied, Toast.LENGTH_SHORT).show()
    }

    private fun clear() {
        if (!clearArmed) {
            clearArmed = true
            Toast.makeText(context, R.string.notes_clear_confirm, Toast.LENGTH_SHORT).show()
            handler.postDelayed({ clearArmed = false }, 3000)
            return
        }
        clearArmed = false
        editor.setText("")
        save()
    }

    private fun button(labelRes: Int, onClick: () -> Unit) = TextView(context).apply {
        text = context.getString(labelRes)
        gravity = Gravity.CENTER
        setTextColor(theme.text)
        setTypeface(typeface, Typeface.BOLD)
        background = theme.rounded(theme.keyBg, dp(14f).toFloat())
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun enableKeyboardOnTouch(field: EditText) {
        field.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                window.setKeyboardEnabled(true)
                v.post {
                    v.requestFocus()
                    context.getSystemService(InputMethodManager::class.java)
                        ?.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
                }
            }
            false
        }
    }

    private fun dp(v: Float) = WindowManagerHelper.dp(context, v)
}
