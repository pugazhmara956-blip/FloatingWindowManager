package com.allapps.floatingwindow.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.PermissionManager
import com.allapps.floatingwindow.ui.MainActivity

/** Shared notification and start helpers for both foreground services. */
object ServiceNotifications {

    private const val TAG = "ServiceNotifications"
    private const val CHANNEL_ID = "floating_tools"

    fun startService(context: Context, serviceClass: Class<out Service>, action: String): Boolean {
        if (!PermissionManager.canDrawOverlays(context)) return false
        return try {
            ContextCompat.startForegroundService(context, Intent(context, serviceClass).setAction(action))
            true
        } catch (e: Exception) {
            Log.w(TAG, "Could not start ${serviceClass.simpleName}", e)
            false
        }
    }

    fun goForeground(service: Service, id: Int, titleRes: Int, textRes: Int, stopAction: String) {
        createChannel(service)
        val openApp = PendingIntent.getActivity(
            service, id,
            Intent(service, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            service, id + 1,
            Intent(service, service.javaClass).setAction(stopAction),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(service, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(service.getString(titleRes))
            .setContentText(service.getString(textRes))
            .setOngoing(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openApp)
            .addAction(0, service.getString(R.string.notif_stop), stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(service, id, notification, type)
        } catch (e: Exception) {
            Log.w(TAG, "Could not enter the foreground state", e)
            service.stopSelf()
        }
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID, context.getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = context.getString(R.string.channel_desc)
            setShowBadge(false)
        }
        context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }
}
