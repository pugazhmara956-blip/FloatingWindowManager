package com.allapps.floatingwindow.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import com.allapps.floatingwindow.core.WindowManagerHelper
import kotlin.math.abs

/**
 * A round, draggable floating button. Used for the main launcher button and for minimized
 * windows. It snaps to the nearest screen edge when released.
 */
class FloatingBubble(
    service: Context,
    theme: OverlayTheme,
    sizeDp: Int,
    iconRes: Int,
    description: String,
    private val animationSpeed: Float,
    private val onTap: () -> Unit,
    private val onLongPress: (() -> Unit)? = null
) {
    private val context = theme.themedContext(service)
    private val wm = WindowManagerHelper.windowManager(context)
    private val sizePx = WindowManagerHelper.dp(context, sizeDp.toFloat())
    val view = ImageView(context)
    val params = WindowManagerHelper.overlayParams(sizePx, sizePx)
    private val handler = Handler(Looper.getMainLooper())
    private var longPressed = false
    private var isShowing = false
    private val longPressRunnable = Runnable {
        longPressed = true
        onLongPress?.invoke()
    }

    init {
        view.background = theme.accentGradient()
        view.setImageResource(iconRes)
        view.setColorFilter(theme.onAccent)
        val pad = sizePx / 4
        view.setPadding(pad, pad, pad, pad)
        view.contentDescription = description
        view.alpha = 0.95f
        // Bubbles never need the keyboard, so outside touches are not needed either.
        params.flags = params.flags and android.view.WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH.inv()
        view.setOnClickListener { onTap() } // Accessibility services use this.
        attachTouch()
    }

    fun show(x: Int, y: Int) {
        params.x = x
        params.y = y
        if (isShowing) {
            WindowManagerHelper.safeUpdate(context, view, params)
            return
        }
        try {
            view.scaleX = 0.5f
            view.scaleY = 0.5f
            wm.addView(view, params)
            isShowing = true
            view.animate().scaleX(1f).scaleY(1f).setDuration((160 / animationSpeed).toLong()).start()
        } catch (e: Exception) {
            Log.w(TAG, "Could not show bubble", e)
        }
    }

    fun remove() {
        handler.removeCallbacks(longPressRunnable)
        if (!isShowing) return
        isShowing = false
        try {
            wm.removeViewImmediate(view)
        } catch (e: Exception) {
            Log.w(TAG, "Bubble already removed", e)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch() {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    longPressed = false
                    if (onLongPress != null) {
                        handler.postDelayed(longPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        dragging = true
                        handler.removeCallbacks(longPressRunnable)
                    }
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        WindowManagerHelper.safeUpdate(context, view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressRunnable)
                    when {
                        dragging -> snapToEdge()
                        !longPressed -> onTap()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (dragging) snapToEdge()
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToEdge() {
        val screen = WindowManagerHelper.screenSize(context)
        val margin = WindowManagerHelper.dp(context, 6f)
        val targetX = if (params.x + sizePx / 2 < screen.x / 2) margin else screen.x - sizePx - margin
        params.y = params.y.coerceIn(WindowManagerHelper.statusBarHeight(context), screen.y - sizePx - margin)
        ValueAnimator.ofInt(params.x, targetX).apply {
            duration = (220 / animationSpeed).toLong()
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                params.x = it.animatedValue as Int
                WindowManagerHelper.safeUpdate(context, view, params)
            }
            start()
        }
    }

    companion object {
        private const val TAG = "FloatingBubble"
    }
}
