package com.allapps.floatingwindow.core

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/**
 * What this phone supports, detected at runtime with public APIs only.
 *
 * freeformAvailable is true when the system offers freeform (floating) windows to other apps,
 * either as a system feature or because the user turned on the developer option.
 * Values that Android does not let apps read are reported as null (unknown).
 */
data class DeviceCapabilities(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdk: Int,
    val systemBuild: String,
    val isXiaomi: Boolean,
    val freeformFeature: Boolean,
    val freeformDeveloperOption: Boolean?,
    val pictureInPicture: Boolean
) {
    val freeformAvailable: Boolean get() = freeformFeature || freeformDeveloperOption == true

    companion object {
        fun detect(context: Context): DeviceCapabilities {
            val pm = context.packageManager
            val maker = Build.MANUFACTURER.lowercase()
            val brand = Build.BRAND.lowercase()
            return DeviceCapabilities(
                manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
                model = Build.MODEL,
                androidVersion = Build.VERSION.RELEASE,
                sdk = Build.VERSION.SDK_INT,
                systemBuild = Build.VERSION.INCREMENTAL,
                isXiaomi = maker.contains("xiaomi") || brand in setOf("xiaomi", "redmi", "poco"),
                freeformFeature = pm.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT),
                freeformDeveloperOption = readGlobalFlag(context, "enable_freeform_support"),
                pictureInPicture = pm.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
            )
        }

        /** Reads a developer setting. Some Android versions block this, which gives null. */
        private fun readGlobalFlag(context: Context, key: String): Boolean? = try {
            Settings.Global.getInt(context.contentResolver, key, 0) == 1
        } catch (e: SecurityException) {
            null
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}
