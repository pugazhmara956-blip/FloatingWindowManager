package com.allapps.floatingwindow.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import com.allapps.floatingwindow.R
import com.allapps.floatingwindow.core.DeviceCapabilities
import com.allapps.floatingwindow.core.PermissionManager
import com.allapps.floatingwindow.service.FloatingSidebarService
import com.allapps.floatingwindow.service.FloatingWindowService
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Explains and requests each permission. */
class PermissionActivity : ContainerActivity() {
    override val titleRes = R.string.permissions_title

    private enum class Status { ALLOWED, NOT_ALLOWED, NOT_NEEDED, MANUAL }

    private class Step(
        @StringRes val title: Int,
        @StringRes val desc: Int,
        @StringRes val button: Int,
        val status: () -> Status,
        val action: () -> Unit
    ) {
        lateinit var statusView: TextView
        lateinit var buttonView: MaterialButton
    }

    private val steps = ArrayList<Step>()

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.perm_rationale_title)
                .setMessage(R.string.perm_denied)
                .setPositiveButton(R.string.open_settings) { _, _ -> openSettings(PermissionManager.appDetailsIntent(this)) }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        refresh()
    }

    override fun build() {
        container.addView(layoutInflater.inflate(R.layout.item_text_line, container, false).apply {
            (this as TextView).setText(R.string.permissions_intro)
        })

        steps.add(Step(R.string.perm_overlay, R.string.perm_overlay_desc, R.string.allow,
            { if (PermissionManager.canDrawOverlays(this)) Status.ALLOWED else Status.NOT_ALLOWED },
            { openSettings(PermissionManager.overlaySettingsIntent(this)) }))

        steps.add(Step(R.string.perm_notifications, R.string.perm_notifications_desc, R.string.allow,
            {
                when {
                    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU -> Status.NOT_NEEDED
                    PermissionManager.hasNotificationPermission(this) -> Status.ALLOWED
                    else -> Status.NOT_ALLOWED
                }
            },
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.perm_rationale_title)
                        .setMessage(R.string.notif_rationale)
                        .setPositiveButton(R.string.allow) { _, _ ->
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        .setNegativeButton(R.string.not_now, null)
                        .show()
                }
            }))

        steps.add(Step(R.string.perm_apps, R.string.perm_apps_desc, R.string.ok,
            { Status.ALLOWED }, { }))

        steps.add(Step(R.string.perm_battery, R.string.perm_battery_desc, R.string.open,
            { if (PermissionManager.isIgnoringBatteryOptimizations(this)) Status.ALLOWED else Status.NOT_ALLOWED },
            { openSettings(PermissionManager.batterySettingsIntent()) }))

        if (DeviceCapabilities.detect(this).isXiaomi) {
            steps.add(Step(R.string.perm_xiaomi_popups, R.string.perm_xiaomi_popups_desc, R.string.open,
                { Status.MANUAL },
                { openXiaomi(PermissionManager.xiaomiOtherPermissionsIntents(this)) }))
            steps.add(Step(R.string.perm_xiaomi_autostart, R.string.perm_xiaomi_autostart_desc, R.string.open,
                { Status.MANUAL },
                { openXiaomi(PermissionManager.xiaomiAutostartIntents(this)) }))
        }

        steps.forEach { step ->
            val card = layoutInflater.inflate(R.layout.item_setup_step, container, false)
            card.findViewById<TextView>(R.id.step_title).setText(step.title)
            card.findViewById<TextView>(R.id.step_desc).setText(step.desc)
            step.statusView = card.findViewById(R.id.step_status)
            step.buttonView = card.findViewById(R.id.step_button)
            step.buttonView.setText(step.button)
            step.buttonView.contentDescription = getString(step.title)
            step.buttonView.setOnClickListener { step.action() }
            container.addView(card)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (PermissionManager.canDrawOverlays(this)) {
            if (settings.bubbleEnabled && !FloatingWindowService.isRunning) {
                FloatingWindowService.send(this, FloatingWindowService.ACTION_START)
            }
            if (settings.sidebarEnabled && !FloatingSidebarService.isRunning) {
                FloatingSidebarService.send(this, FloatingSidebarService.ACTION_START)
            }
        }
    }

    private fun refresh() {
        steps.forEach { step ->
            val status = step.status()
            val (text, color) = when (status) {
                Status.ALLOWED -> R.string.status_allowed to R.color.accent_green
                Status.NOT_ALLOWED -> R.string.status_not_allowed to R.color.accent_amber
                Status.NOT_NEEDED -> R.string.status_not_needed to R.color.text_muted
                Status.MANUAL -> R.string.status_check_manually to R.color.accent_2
            }
            step.statusView.setText(text)
            step.statusView.setTextColor(getColor(color))
            step.buttonView.visibility =
                if (status == Status.ALLOWED || status == Status.NOT_NEEDED) View.GONE else View.VISIBLE
        }
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(PermissionManager.appDetailsIntent(this))
                Toast.makeText(this, R.string.settings_open_failed, Toast.LENGTH_LONG).show()
            } catch (ignored: Exception) {
                // No settings screen available.
            }
        }
    }

    private fun openXiaomi(intents: List<Intent>) {
        if (!PermissionManager.openFirstAvailable(this, intents)) {
            Toast.makeText(this, R.string.settings_open_failed, Toast.LENGTH_LONG).show()
        }
    }
}

/** Plain English help, including what Android allows on this phone. */
class HelpActivity : ContainerActivity() {
    override val titleRes = R.string.help_title

    override fun build() {
        val sections = listOf(
            R.string.help_possible_title to R.string.help_possible_body,
            R.string.help_cannot_title to R.string.help_cannot_body,
            R.string.help_bubble_title to R.string.help_bubble_body,
            R.string.help_sidebar_title to R.string.help_sidebar_body,
            R.string.help_xiaomi_title to R.string.help_xiaomi_body,
            R.string.help_trouble_title to R.string.help_trouble_body,
            R.string.help_privacy_title to R.string.help_privacy_body
        )
        sections.forEach { (heading, body) ->
            val card = layoutInflater.inflate(R.layout.item_help_section, container, false)
            card.findViewById<TextView>(R.id.help_heading).setText(heading)
            card.findViewById<TextView>(R.id.help_body).setText(body)
            container.addView(card)
        }
    }
}
