package com.allapps.floatingwindow.core

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Checks and opens every permission the app uses, including Xiaomi-specific pages. */
object PermissionManager {

    private const val SECURITY_CENTER = "com.miui.securitycenter"

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun hasNotificationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun isIgnoringBatteryOptimizations(context: Context): Boolean =
        context.getSystemService(PowerManager::class.java)
            ?.isIgnoringBatteryOptimizations(context.packageName) == true

    fun overlaySettingsIntent(context: Context) =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))

    /** Opens the battery optimization list (no special permission needed for this page). */
    @SuppressLint("BatteryLife")
    fun batterySettingsIntent() = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    fun appDetailsIntent(context: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))

    fun xiaomiOtherPermissionsIntents(context: Context): List<Intent> = listOf(
        Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName(SECURITY_CENTER, "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", context.packageName),
        Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName(SECURITY_CENTER, "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
            .putExtra("extra_pkgname", context.packageName),
        appDetailsIntent(context)
    )

    fun xiaomiAutostartIntents(context: Context): List<Intent> = listOf(
        Intent().setComponent(
            ComponentName(SECURITY_CENTER, "com.miui.permcenter.autostart.AutoStartManagementActivity")
        ),
        appDetailsIntent(context)
    )

    /** Opens the first page that exists. Returns false if only the fallback (or nothing) opened. */
    fun openFirstAvailable(activity: Activity, intents: List<Intent>): Boolean {
        intents.forEachIndexed { index, intent ->
            try {
                activity.startActivity(intent)
                return index < intents.lastIndex
            } catch (e: Exception) {
                // Try the next page.
            }
        }
        return false
    }
}
