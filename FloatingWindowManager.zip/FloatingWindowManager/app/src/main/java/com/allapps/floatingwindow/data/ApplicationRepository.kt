package com.allapps.floatingwindow.data

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.Executors

/**
 * An estimate of whether an app can run in a resizable window.
 * Android has no public API that reports this exactly, so the estimate uses the app's target
 * Android version: apps targeting Android 7.0 (API 24) or newer are resizable unless they opt
 * out; older apps are not resizable.
 */
enum class WindowSupport { LIKELY, UNLIKELY }

data class AppInfo(
    val key: String,
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable,
    val targetSdk: Int,
    val windowSupport: WindowSupport,
    val isSystem: Boolean
) {
    val isPopular: Boolean get() = ApplicationRepository.isPopular(packageName)
}

/** Loads the apps that appear in the app drawer. Loading runs on a background thread. */
object ApplicationRepository {

    private const val TAG = "AppRepository"

    /** Popular apps highlighted in the Popular filter (shown only if installed). */
    private val POPULAR_PACKAGES = setOf(
        "com.whatsapp", "com.whatsapp.w4b",
        "com.instagram.android",
        "com.google.android.youtube",
        "com.android.chrome",
        "com.facebook.katana", "com.facebook.lite",
        "org.telegram.messenger",
        "com.google.android.gm",
        "com.google.android.apps.maps",
        "com.miui.calculator", "com.google.android.calculator", "com.android.calculator2",
        "com.android.settings"
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var cache: List<AppInfo>? = null

    fun isPopular(packageName: String) = packageName in POPULAR_PACKAGES

    fun cached(): List<AppInfo>? = cache

    fun invalidate() {
        cache = null
    }

    fun findByKey(key: String): AppInfo? = cache?.firstOrNull { it.key == key }

    /** Delivers the app list on the main thread. Uses the cache unless [force] is true. */
    fun load(context: Context, force: Boolean = false, callback: (List<AppInfo>) -> Unit) {
        val current = cache
        if (current != null && !force) {
            callback(current)
            return
        }
        val app = context.applicationContext
        executor.execute {
            val list = try {
                query(app)
            } catch (e: Exception) {
                Log.w(TAG, "Could not load apps", e)
                emptyList()
            }
            cache = list
            mainHandler.post { callback(list) }
        }
    }

    private fun query(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return results
            .filter { it.activityInfo.packageName != context.packageName }
            .map { ri ->
                val ai = ri.activityInfo
                val appInfo = ai.applicationInfo
                AppInfo(
                    key = "${ai.packageName}/${ai.name}",
                    label = ri.loadLabel(pm).toString(),
                    packageName = ai.packageName,
                    activityName = ai.name,
                    icon = ri.loadIcon(pm),
                    targetSdk = appInfo.targetSdkVersion,
                    windowSupport = estimateSupport(ai),
                    isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
    }

    private fun estimateSupport(ai: ActivityInfo): WindowSupport =
        if (ai.applicationInfo.targetSdkVersion >= Build.VERSION_CODES.N) WindowSupport.LIKELY
        else WindowSupport.UNLIKELY
}
