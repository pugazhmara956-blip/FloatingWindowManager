# All Apps Floating Window Manager

A native Android app (Kotlin) for the Redmi 14C 5G that adds the best multitasking possible without root: a floating launcher for all your apps, real floating tool windows, a floating button, and an edge-swipe sidebar. Everything is free, offline and English-only.

---

## 1. What the Redmi 14C 5G allows (investigation)

- **Split screen:** Xiaomi offers split screen on many models, but users report that the Redmi 14C does not support it. Android only allows another app to open "side by side" while split screen is already active.
- **Floating (freeform) windows for other apps:** Android opens an app in a resizable window only when the phone's system offers freeform windowing. This is a system feature or a developer option ("Enable freeform windows"). The only public tool is `ActivityOptions.setLaunchBounds`, which the system ignores when freeform is off. Apps such as Taskbar force freeform mode with hidden system functions. This project does **not** do that, as you requested.
- **Xiaomi's own floating windows:** some HyperOS versions offer floating windows from the Recents screen. Only the user can start these; other apps cannot trigger them.
- **Overlays (`SYSTEM_ALERT_WINDOW`):** these are always allowed once you grant "Display over other apps". They are used for the floating button, the sidebar and this app's own floating windows.
- **Embedding other apps inside a window:** this is not possible for normal apps. This app never shows a fake copy of another app.

**So the app does this:**
1. When the system offers freeform windows, apps open in real floating windows (`setLaunchBounds`).
2. While split screen is active, apps open side by side (`FLAG_ACTIVITY_LAUNCH_ADJACENT`).
3. Otherwise apps open in full screen, and a short message explains why.
4. The floating launcher, calculator, quick notes and sidebar are real overlay windows. You can move, resize, snap, minimize into bubbles, maximize, close and fade them.

The home screen shows what your phone supports, detected live: Android version, system build, freeform availability and picture-in-picture.

## 2. Architecture

```
app/src/main/java/com/allapps/floatingwindow/
├── FloatingApp.kt                 Applies dark, light or system theme
├── data/
│   ├── SettingsRepository.kt      All settings, favorites, recents and notes (SharedPreferences)
│   └── ApplicationRepository.kt   Lists launchable apps (background thread) and estimates window support
├── core/
│   ├── AppLauncher.kt             Full screen, floating window or side-by-side launches, with explanations
│   ├── WindowManagerHelper.kt     Overlay parameters, screen size, focus switching and snapping
│   ├── PermissionManager.kt       Permission checks and Xiaomi settings pages
│   └── DeviceCapabilities.kt      Runtime detection of multitasking support
├── overlay/
│   ├── FloatingWindow.kt          Movable, resizable window with title bar and controls
│   ├── FloatingBubble.kt          Draggable button that snaps to the edges
│   ├── LauncherPanel.kt           Floating launcher (search, favorites, recent, all)
│   ├── ToolPanels.kt              Floating calculator and quick notes
│   └── OverlayTheme.kt            Overlay colors for dark and light themes
├── service/
│   ├── FloatingWindowService.kt   Floating button and window management
│   ├── FloatingSidebarService.kt  Edge handle and sidebar
│   └── ServiceNotifications.kt    Shared foreground notification
├── receiver/BootReceiver.kt       Optional restart after reboot
└── ui/                            Home, All Apps, Favorites, Recent, Sidebar settings,
                                   Window settings, Appearance, Permissions, Help
```

The services do no background work. They only react to your taps, so battery use stays very low. The floating window service stops itself when the button is off and no windows are open.

## 3. Features

- **All apps:** icons, names, search, filters (All, Popular, Downloaded, System), favorites (star), and a menu with open full screen, open in floating window, open side by side, app info, and "Why can't this open in a window?". Popular apps such as WhatsApp, Instagram, YouTube, Chrome, Facebook, Telegram, Gmail, Maps, Calculator and Settings appear under **Popular** when installed.
- **Window support estimate:** apps targeting Android 7.0 or newer are marked "likely supported"; older apps "probably not supported". Android has no public way to check this exactly, so it is labelled as an estimate.
- **Floating windows:** title bar, minimize (into a bubble), maximize or restore, close, resize handle, drag anywhere, snapping (left half, right half, bottom half, top to maximize), rounded corners, adjustable opacity, several windows at once with tap-to-front, and cascading positions.
- **Floating button:** tap opens or minimizes the floating launcher. Press and hold for the calculator, notes, sidebar, or to hide the button.
- **Sidebar:** swipe in from the edge handle, or tap it. It holds favorites, recent apps, tools (all apps, calculator, notes) and quick settings (Wi-Fi, Internet, Bluetooth, Volume, Flashlight, Display, Settings). The position, height, opacity and sections are customizable.
- **Customization:** window size and position, sidebar position and opacity, floating button size, corner radius, dark, light or system theme, animation speed, default launch mode, snapping, and start after restart.

## 4. Permissions

| Permission | Why |
|---|---|
| Display over other apps | The floating button, windows and sidebar. |
| Notifications | Android requires a notification for the background services. |
| Foreground service (special use) | Keeps the button and sidebar available. |
| Package visibility (`<queries>` for launcher apps) | Lists apps from your app drawer. No `QUERY_ALL_PACKAGES`. |
| Run at startup (optional) | Brings the tools back after a restart. |

No internet, accessibility, usage access or root. The app never reads or controls other apps.

## 5. Beginner guide

### Build without a computer (GitHub, like the first app)
1. Create a **new** empty GitHub repository, for example `FloatingWindowManager`.
2. Add a README file, upload **FloatingWindowManager.zip** with **Add file → Upload files**, then create `.github/workflows/main.yml` with the same build text as before.
3. Open **Actions**, wait for the green tick and download the artifact.

### Build with Android Studio
1. Install Android Studio, choose **Open** and select the `FloatingWindowManager` folder. Wait for Gradle sync to finish.
2. Choose **Build → Build APK(s)**. The file is `app/build/outputs/apk/debug/app-debug.apk`.

### Install on the Redmi 14C 5G
Copy the APK to the phone, tap it, allow **Install unknown apps** and tap **Install**.

### Set up
1. Open the app and tap **Finish Setup**, then **Allow** next to **Display over other apps**.
2. Allow notifications. On Xiaomi, also open **Xiaomi pop-up windows** and allow "Display pop-up windows while running in the background". Without it, apps may not open from the launcher and sidebar.
3. On the home screen, turn on **Floating button** and **Floating sidebar**.

### Configure the sidebar
Open **Sidebar Settings**. Choose the left or right edge, the handle height and the opacity, pick the sections, then tap **Open Sidebar Now** to test.

### Open apps in floating windows
Tap the floating button, find an app and tap it. Press and hold an app for all options. If your phone does not offer freeform windows, the app opens in full screen and a message explains why. To enable freeform where your system supports it: **Settings → Additional settings → Developer options → Enable freeform windows** (the option may not exist on HyperOS). You can also try Xiaomi's floating window from the Recents screen.

### Troubleshooting
- **Nothing appears:** allow Display over other apps.
- **Apps don't open from the sidebar:** allow Xiaomi pop-up windows while running in the background.
- **The button disappears:** allow unrestricted battery usage and lock the app in Recents.
- **The keyboard doesn't show in a floating window:** tap the text box once more. Tap outside the window or press Back to give the keyboard back to the app underneath.
- **An app always opens in full screen:** the phone or the app does not support freeform windows.

## 6. Testing status (honest)

This workspace has no Android SDK or Kotlin compiler, so the project has **not been compiled or run yet**. I checked that every XML file is valid, every resource and view ID referenced in the code exists, all imports of the app's own classes resolve, brackets balance, icon paths are valid, and all text is English. The first real build will happen on GitHub or in Android Studio. Send any build error and it will be fixed.

## 7. Known limitations

- Other apps open in real floating windows only if the system offers freeform windowing.
- "Side by side" works only while split screen is active, which the Redmi 14C may not offer.
- Overlays cannot appear on the lock screen or over some secure screens.
- The recent apps list shows only apps opened through this app. Reading the full system list would need usage access.
- Window support is an estimate, because Android offers no public API to check it exactly.
